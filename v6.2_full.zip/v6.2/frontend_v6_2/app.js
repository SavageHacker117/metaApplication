
const logDiv = document.getElementById('log');
const statusDiv = document.getElementById('status');

function log(msg) {
  logDiv.innerHTML += msg + "<br>";
  logDiv.scrollTop = logDiv.scrollHeight;
}

// Modular event log
const ws = new WebSocket("ws://localhost:8765");

ws.onopen = () => {
  statusDiv.textContent = "WebSocket connected! Agent: ChatGBT";
  log("<b>[System]</b> Connected to backend.");
};

ws.onmessage = (event) => {
  const data = JSON.parse(event.data);
  log(`<b>From ${data.from}:</b> ${JSON.stringify(data.payload)}`);
};

// Example agent name for demo
const AGENT_NAME = "ChatGBT";

function requestVisualization() {
  ws.send(JSON.stringify({
    type: "visualization:request",
    from: AGENT_NAME,
    to: "Manus",
    payload: { what: "reward_curve", params: { episodes: [10,11,12] } }
  }));
  log("Requested <i>reward_curve</i> visualization from Manus.");
}

function generateCode() {
  ws.send(JSON.stringify({
    type: "code:generate",
    from: AGENT_NAME,
    to: "Manus",
    payload: { prompt: "Print hello world" }
  }));
  log("Asked Manus for code generation.");
}
