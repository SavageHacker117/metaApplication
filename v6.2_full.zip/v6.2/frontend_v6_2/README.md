
# AI Collab v6.2 Frontend

## Usage

1. Open `index.html` in your browser.
2. Click the buttons to interact with the Manus v6.2 Python backend (see logs below).
3. Expand by wiring to Three.js, React, or any modern SPA as needed.

All messages use the protocol in `/shared/protocol.md`.
