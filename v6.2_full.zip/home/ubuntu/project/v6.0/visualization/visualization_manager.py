"""
Visualization and Monitoring Manager for Version 5 BETA 1

This module provides comprehensive visualization and monitoring capabilities
for the RL training system, including real-time progress tracking, image grids,
GIF generation, and interactive dashboards.

Key features:
- Real-time training progress visualization
- Image grid generation for episode comparisons
- Animated GIF creation for agent behavior
- TensorBoard and WandB integration
- Interactive web dashboard
- Performance monitoring and alerts
- Comprehensive analytics and reporting
"""

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from matplotlib.gridspec import GridSpec
import seaborn as sns
import cv2
from PIL import Image, ImageDraw, ImageFont
import logging
from typing import Dict, List, Any, Optional, Tuple, Union, Callable
from dataclasses import dataclass, field
from collections import deque, defaultdict
from pathlib import Path
import time
import json
import threading
from datetime import datetime
import io
import base64

# Visualization libraries
try:
    import plotly.graph_objects as go
    import plotly.express as px
    from plotly.subplots import make_subplots
    import plotly.offline as pyo
    PLOTLY_AVAILABLE = True
except ImportError:
    PLOTLY_AVAILABLE = False

try:
    from tensorboardX import SummaryWriter
    TENSORBOARD_AVAILABLE = True
except ImportError:
    try:
        from torch.utils.tensorboard import SummaryWriter
        TENSORBOARD_AVAILABLE = True
    except ImportError:
        TENSORBOARD_AVAILABLE = False

try:
    import wandb
    WANDB_AVAILABLE = True
except ImportError:
    WANDB_AVAILABLE = False

logger = logging.getLogger(__name__)

@dataclass
class VisualizationConfig:
    """Configuration for visualization system."""
    
    # Output settings
    output_directory: str = "visualizations_v5"
    image_format: str = "png"
    gif_format: str = "gif"
    video_format: str = "mp4"
    
    # Image grid settings
    grid_size: Tuple[int, int] = (4, 4)  # rows, cols
    image_size: Tuple[int, int] = (256, 256)
    grid_spacing: int = 10
    font_size: int = 12
    
    # GIF settings
    gif_fps: int = 10
    gif_duration: float = 5.0  # seconds
    gif_loop: bool = True
    gif_optimize: bool = True
    
    # Dashboard settings
    dashboard_port: int = 5002
    dashboard_update_interval: float = 2.0  # seconds
    dashboard_history_length: int = 1000
    
    # Monitoring settings
    enable_tensorboard: bool = True
    enable_wandb: bool = True
    enable_dashboard: bool = True
    
    # Performance settings
    max_concurrent_renders: int = 4
    cache_size: int = 100
    async_rendering: bool = True
    
    # Alert settings
    enable_alerts: bool = True
    performance_threshold: float = 0.1  # Alert if performance drops below this
    memory_threshold: float = 0.9  # Alert if memory usage above this

class VisualizationManager:
    """
    Comprehensive visualization and monitoring manager.
    
    Handles all aspects of training visualization including real-time monitoring,
    image generation, GIF creation, and interactive dashboards.
    """
    
    def __init__(self, config: Optional[VisualizationConfig] = None):
        self.config = config or VisualizationConfig()
        
        # Setup output directory
        self.output_dir = Path(self.config.output_directory)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        
        # Initialize logging systems
        self.tensorboard_writer = None
        self.wandb_run = None
        
        # Data storage
        self.training_metrics: Dict[str, deque] = defaultdict(lambda: deque(maxlen=self.config.dashboard_history_length))
        self.episode_images: deque = deque(maxlen=self.config.cache_size)
        self.performance_alerts: List[Dict[str, Any]] = []
        
        # Rendering management
        self.render_queue: deque = deque()
        self.render_lock = threading.Lock()
        self.render_threads: List[threading.Thread] = []
        
        # Dashboard components
        self.dashboard_app = None
        self.dashboard_thread = None
        self.dashboard_data = {}
        
        # Initialize systems
        self._initialize_logging_systems()
        self._start_render_workers()
        
        if self.config.enable_dashboard:
            self._start_dashboard()
        
        logger.info("Visualization Manager V5 initialized")
    
    def _initialize_logging_systems(self):
        """Initialize TensorBoard and WandB logging."""
        
        if self.config.enable_tensorboard and TENSORBOARD_AVAILABLE:
            log_dir = self.output_dir / "tensorboard" / datetime.now().strftime("%Y%m%d_%H%M%S")
            self.tensorboard_writer = SummaryWriter(str(log_dir))
            logger.info(f"TensorBoard logging initialized: {log_dir}")
        
        if self.config.enable_wandb and WANDB_AVAILABLE:
            try:
                self.wandb_run = wandb.init(
                    project="rl-training-v5-visualization",
                    tags=["version5", "beta1", "visualization"]
                )
                logger.info("WandB logging initialized")
            except Exception as e:
                logger.warning(f"Failed to initialize WandB: {e}")
    
    def _start_render_workers(self):
        """Start background rendering workers."""
        
        for i in range(self.config.max_concurrent_renders):
            worker = threading.Thread(target=self._render_worker, daemon=True)
            worker.start()
            self.render_threads.append(worker)
        
        logger.info(f"Started {self.config.max_concurrent_renders} render workers")
    
    def _render_worker(self):
        """Background worker for rendering tasks."""
        
        while True:
            try:
                with self.render_lock:
                    if not self.render_queue:
                        time.sleep(0.1)
                        continue
                    
                    task = self.render_queue.popleft()
                
                # Execute rendering task
                task_type = task['type']
                task_data = task['data']
                
                if task_type == 'image_grid':
                    self._render_image_grid_worker(task_data)
                elif task_type == 'gif':
                    self._render_gif_worker(task_data)
                elif task_type == 'plot':
                    self._render_plot_worker(task_data)
                
            except Exception as e:
                logger.error(f"Render worker error: {e}")
                time.sleep(1)
    
    def update_metrics(self, episode_data: Dict[str, Any]):
        """Update training metrics for visualization."""
        
        episode = episode_data.get('episode', 0)
        
        # Store core metrics
        self.training_metrics['episode'].append(episode)
        self.training_metrics['total_reward'].append(episode_data.get('total_reward', 0))
        self.training_metrics['episode_length'].append(episode_data.get('steps', 0))
        self.training_metrics['success_rate'].append(float(episode_data.get('success', False)))
        
        # NeRF metrics
        nerf_assets = episode_data.get('nerf_assets_used', set())
        self.training_metrics['nerf_asset_count'].append(len(nerf_assets))
        self.training_metrics['nerf_reward'].append(sum(episode_data.get('nerf_rewards', [])))
        
        # Performance metrics
        performance_metrics = episode_data.get('performance_metrics', {})
        for key, value in performance_metrics.items():
            self.training_metrics[f'performance_{key}'].append(value)
        
        # Curriculum metrics
        self.training_metrics['difficulty'].append(episode_data.get('difficulty', 0.5))
        
        # HITL metrics
        hitl_rating = episode_data.get('hitl_rating')
        if hitl_rating is not None:
            self.training_metrics['hitl_rating'].append(hitl_rating)
        
        # Update external logging systems
        self._update_tensorboard(episode_data)
        self._update_wandb(episode_data)
        
        # Check for alerts
        self._check_performance_alerts(episode_data)
    
    def _update_tensorboard(self, episode_data: Dict[str, Any]):
        """Update TensorBoard with current metrics."""
        
        if not self.tensorboard_writer:
            return
        
        episode = episode_data.get('episode', 0)
        
        # Basic metrics
        self.tensorboard_writer.add_scalar('Training/Total_Reward', episode_data.get('total_reward', 0), episode)
        self.tensorboard_writer.add_scalar('Training/Episode_Length', episode_data.get('steps', 0), episode)
        self.tensorboard_writer.add_scalar('Training/Success', float(episode_data.get('success', False)), episode)
        self.tensorboard_writer.add_scalar('Training/Difficulty', episode_data.get('difficulty', 0.5), episode)
        
        # NeRF metrics
        nerf_assets = episode_data.get('nerf_assets_used', set())
        self.tensorboard_writer.add_scalar('NeRF/Asset_Count', len(nerf_assets), episode)
        self.tensorboard_writer.add_scalar('NeRF/Total_Reward', sum(episode_data.get('nerf_rewards', [])), episode)
        
        # Performance metrics
        performance_metrics = episode_data.get('performance_metrics', {})
        for key, value in performance_metrics.items():
            self.tensorboard_writer.add_scalar(f'Performance/{key}', value, episode)
        
        # HITL metrics
        hitl_rating = episode_data.get('hitl_rating')
        if hitl_rating is not None:
            self.tensorboard_writer.add_scalar('HITL/Rating', hitl_rating, episode)
        
        # Add histograms for reward distribution
        if len(self.training_metrics['total_reward']) >= 10:
            recent_rewards = list(self.training_metrics['total_reward'])[-100:]
            self.tensorboard_writer.add_histogram('Training/Reward_Distribution', np.array(recent_rewards), episode)
    
    def _update_wandb(self, episode_data: Dict[str, Any]):
        """Update WandB with current metrics."""
        
        if not self.wandb_run:
            return
        
        log_data = {
            'episode': episode_data.get('episode', 0),
            'total_reward': episode_data.get('total_reward', 0),
            'episode_length': episode_data.get('steps', 0),
            'success': float(episode_data.get('success', False)),
            'difficulty': episode_data.get('difficulty', 0.5),
            'nerf_asset_count': len(episode_data.get('nerf_assets_used', set())),
            'nerf_total_reward': sum(episode_data.get('nerf_rewards', []))
        }
        
        # Add performance metrics
        performance_metrics = episode_data.get('performance_metrics', {})
        for key, value in performance_metrics.items():
            log_data[f'performance_{key}'] = value
        
        # Add HITL rating if available
        hitl_rating = episode_data.get('hitl_rating')
        if hitl_rating is not None:
            log_data['hitl_rating'] = hitl_rating
        
        wandb.log(log_data)
    
    def generate_image_grid(self, 
                          images: List[np.ndarray], 
                          titles: Optional[List[str]] = None,
                          save_path: Optional[str] = None,
                          async_render: bool = True) -> Optional[str]:
        """
        Generate an image grid from a list of images.
        
        Args:
            images: List of images as numpy arrays
            titles: Optional titles for each image
            save_path: Optional path to save the grid
            async_render: Whether to render asynchronously
            
        Returns:
            Path to saved image grid or None if async
        """
        
        if not images:
            logger.warning("No images provided for grid generation")
            return None
        
        task_data = {
            'images': images,
            'titles': titles or [f"Image {i+1}" for i in range(len(images))],
            'save_path': save_path or str(self.output_dir / f"image_grid_{int(time.time())}.{self.config.image_format}"),
            'timestamp': time.time()
        }
        
        if async_render:
            with self.render_lock:
                self.render_queue.append({'type': 'image_grid', 'data': task_data})
            return None
        else:
            return self._render_image_grid_worker(task_data)
    
    def _render_image_grid_worker(self, task_data: Dict[str, Any]) -> str:
        """Worker function to render image grid."""
        
        images = task_data['images']
        titles = task_data['titles']
        save_path = task_data['save_path']
        
        # Calculate grid dimensions
        n_images = len(images)
        grid_rows, grid_cols = self.config.grid_size
        
        # Adjust grid size if needed
        if n_images > grid_rows * grid_cols:
            grid_cols = int(np.ceil(np.sqrt(n_images)))
            grid_rows = int(np.ceil(n_images / grid_cols))
        
        # Create figure
        fig, axes = plt.subplots(grid_rows, grid_cols, figsize=(grid_cols * 3, grid_rows * 3))
        if grid_rows == 1 and grid_cols == 1:
            axes = [axes]
        elif grid_rows == 1 or grid_cols == 1:
            axes = axes.flatten()
        else:
            axes = axes.flatten()
        
        # Plot images
        for i, (image, title) in enumerate(zip(images, titles)):
            if i >= len(axes):
                break
            
            ax = axes[i]
            
            # Handle different image formats
            if len(image.shape) == 3 and image.shape[2] == 3:
                ax.imshow(image)
            elif len(image.shape) == 2:
                ax.imshow(image, cmap='gray')
            else:
                ax.imshow(image)
            
            ax.set_title(title, fontsize=self.config.font_size)
            ax.axis('off')
        
        # Hide unused subplots
        for i in range(len(images), len(axes)):
            axes[i].axis('off')
        
        plt.tight_layout()
        plt.savefig(save_path, dpi=150, bbox_inches='tight')
        plt.close()
        
        logger.debug(f"Image grid saved: {save_path}")
        return save_path
    
    def generate_training_gif(self, 
                            episode_images: List[np.ndarray],
                            episode_data: List[Dict[str, Any]],
                            save_path: Optional[str] = None,
                            async_render: bool = True) -> Optional[str]:
        """
        Generate animated GIF showing training progress.
        
        Args:
            episode_images: List of images from episodes
            episode_data: Corresponding episode data
            save_path: Optional path to save GIF
            async_render: Whether to render asynchronously
            
        Returns:
            Path to saved GIF or None if async
        """
        
        if not episode_images:
            logger.warning("No images provided for GIF generation")
            return None
        
        task_data = {
            'images': episode_images,
            'episode_data': episode_data,
            'save_path': save_path or str(self.output_dir / f"training_progress_{int(time.time())}.{self.config.gif_format}"),
            'timestamp': time.time()
        }
        
        if async_render:
            with self.render_lock:
                self.render_queue.append({'type': 'gif', 'data': task_data})
            return None
        else:
            return self._render_gif_worker(task_data)
    
    def _render_gif_worker(self, task_data: Dict[str, Any]) -> str:
        """Worker function to render training GIF."""
        
        images = task_data['images']
        episode_data = task_data['episode_data']
        save_path = task_data['save_path']
        
        # Prepare frames
        frames = []
        
        for i, (image, data) in enumerate(zip(images, episode_data)):
            # Create frame with overlay information
            frame = self._create_gif_frame(image, data, i)
            frames.append(frame)
        
        # Calculate frame duration
        frame_duration = int(1000 / self.config.gif_fps)  # milliseconds
        
        # Save GIF
        if frames:
            frames[0].save(
                save_path,
                save_all=True,
                append_images=frames[1:],
                duration=frame_duration,
                loop=0 if self.config.gif_loop else 1,
                optimize=self.config.gif_optimize
            )
        
        logger.debug(f"Training GIF saved: {save_path}")
        return save_path
    
    def _create_gif_frame(self, image: np.ndarray, episode_data: Dict[str, Any], frame_index: int) -> Image.Image:
        """Create a single frame for the training GIF with overlay information."""
        
        # Convert numpy array to PIL Image
        if len(image.shape) == 3:
            pil_image = Image.fromarray(image.astype(np.uint8))
        else:
            pil_image = Image.fromarray(image.astype(np.uint8)).convert('RGB')
        
        # Resize to standard size
        pil_image = pil_image.resize(self.config.image_size)
        
        # Create overlay with episode information
        draw = ImageDraw.Draw(pil_image)
        
        try:
            font = ImageFont.truetype("arial.ttf", self.config.font_size)
        except:
            font = ImageFont.load_default()
        
        # Overlay text
        episode = episode_data.get('episode', frame_index)
        reward = episode_data.get('total_reward', 0)
        success = episode_data.get('success', False)
        
        overlay_text = f"Episode: {episode}\nReward: {reward:.2f}\nSuccess: {'Yes' if success else 'No'}"
        
        # Add semi-transparent background for text
        text_bbox = draw.textbbox((0, 0), overlay_text, font=font)
        text_width = text_bbox[2] - text_bbox[0]
        text_height = text_bbox[3] - text_bbox[1]
        
        # Create overlay
        overlay = Image.new('RGBA', pil_image.size, (0, 0, 0, 0))
        overlay_draw = ImageDraw.Draw(overlay)
        
        # Background rectangle
        overlay_draw.rectangle(
            [(5, 5), (text_width + 15, text_height + 15)],
            fill=(0, 0, 0, 128)
        )
        
        # Text
        overlay_draw.text((10, 10), overlay_text, fill=(255, 255, 255, 255), font=font)
        
        # Composite overlay onto image
        pil_image = Image.alpha_composite(pil_image.convert('RGBA'), overlay).convert('RGB')
        
        return pil_image
    
    def generate_training_plots(self, save_directory: Optional[str] = None) -> Dict[str, str]:
        """Generate comprehensive training plots."""
        
        save_dir = Path(save_directory) if save_directory else self.output_dir / "plots"
        save_dir.mkdir(parents=True, exist_ok=True)
        
        plots = {}
        
        # Reward progression plot
        if self.training_metrics['total_reward']:
            plots['reward_progression'] = self._create_reward_plot(save_dir)
        
        # Success rate plot
        if self.training_metrics['success_rate']:
            plots['success_rate'] = self._create_success_rate_plot(save_dir)
        
        # NeRF usage plot
        if self.training_metrics['nerf_asset_count']:
            plots['nerf_usage'] = self._create_nerf_usage_plot(save_dir)
        
        # Performance metrics plot
        performance_keys = [k for k in self.training_metrics.keys() if k.startswith('performance_')]
        if performance_keys:
            plots['performance_metrics'] = self._create_performance_plot(save_dir, performance_keys)
        
        # Curriculum progression plot
        if self.training_metrics['difficulty']:
            plots['curriculum_progression'] = self._create_curriculum_plot(save_dir)
        
        # HITL feedback plot
        if self.training_metrics['hitl_rating']:
            plots['hitl_feedback'] = self._create_hitl_plot(save_dir)
        
        return plots
    
    def _create_reward_plot(self, save_dir: Path) -> str:
        """Create reward progression plot."""
        
        episodes = list(self.training_metrics['episode'])
        rewards = list(self.training_metrics['total_reward'])
        
        plt.figure(figsize=(12, 6))
        
        # Plot raw rewards
        plt.subplot(1, 2, 1)
        plt.plot(episodes, rewards, alpha=0.6, linewidth=1, label='Episode Rewards')
        
        # Add moving average
        if len(rewards) > 10:
            window = min(50, len(rewards) // 4)
            moving_avg = np.convolve(rewards, np.ones(window)/window, mode='valid')
            plt.plot(episodes[window-1:], moving_avg, linewidth=2, label=f'Moving Average ({window})')
        
        plt.xlabel('Episode')
        plt.ylabel('Total Reward')
        plt.title('Training Reward Progression')
        plt.legend()
        plt.grid(True, alpha=0.3)
        
        # Plot reward distribution
        plt.subplot(1, 2, 2)
        plt.hist(rewards, bins=30, alpha=0.7, edgecolor='black')
        plt.xlabel('Total Reward')
        plt.ylabel('Frequency')
        plt.title('Reward Distribution')
        plt.grid(True, alpha=0.3)
        
        plt.tight_layout()
        
        save_path = save_dir / "reward_progression.png"
        plt.savefig(save_path, dpi=150, bbox_inches='tight')
        plt.close()
        
        return str(save_path)
    
    def _create_success_rate_plot(self, save_dir: Path) -> str:
        """Create success rate plot."""
        
        episodes = list(self.training_metrics['episode'])
        success_rates = list(self.training_metrics['success_rate'])
        
        # Calculate moving success rate
        window = min(20, len(success_rates) // 4) if len(success_rates) > 4 else len(success_rates)
        moving_success = []
        
        for i in range(window, len(success_rates) + 1):
            moving_success.append(np.mean(success_rates[i-window:i]))
        
        plt.figure(figsize=(10, 6))
        
        # Plot individual successes
        plt.scatter(episodes, success_rates, alpha=0.5, s=20, label='Individual Episodes')
        
        # Plot moving average
        if moving_success:
            plt.plot(episodes[window-1:], moving_success, linewidth=3, color='red', label=f'Moving Success Rate ({window})')
        
        plt.xlabel('Episode')
        plt.ylabel('Success Rate')
        plt.title('Training Success Rate Progression')
        plt.ylim(-0.1, 1.1)
        plt.legend()
        plt.grid(True, alpha=0.3)
        
        save_path = save_dir / "success_rate.png"
        plt.savefig(save_path, dpi=150, bbox_inches='tight')
        plt.close()
        
        return str(save_path)
    
    def _create_nerf_usage_plot(self, save_dir: Path) -> str:
        """Create NeRF asset usage plot."""
        
        episodes = list(self.training_metrics['episode'])
        asset_counts = list(self.training_metrics['nerf_asset_count'])
        nerf_rewards = list(self.training_metrics['nerf_reward'])
        
        plt.figure(figsize=(12, 8))
        
        # Asset count over time
        plt.subplot(2, 2, 1)
        plt.plot(episodes, asset_counts, linewidth=2)
        plt.xlabel('Episode')
        plt.ylabel('NeRF Assets Used')
        plt.title('NeRF Asset Usage Over Time')
        plt.grid(True, alpha=0.3)
        
        # NeRF reward over time
        plt.subplot(2, 2, 2)
        plt.plot(episodes, nerf_rewards, linewidth=2, color='green')
        plt.xlabel('Episode')
        plt.ylabel('NeRF Reward')
        plt.title('NeRF Reward Progression')
        plt.grid(True, alpha=0.3)
        
        # Asset count distribution
        plt.subplot(2, 2, 3)
        plt.hist(asset_counts, bins=max(1, max(asset_counts)), alpha=0.7, edgecolor='black')
        plt.xlabel('Number of Assets Used')
        plt.ylabel('Frequency')
        plt.title('Asset Usage Distribution')
        plt.grid(True, alpha=0.3)
        
        # Correlation between asset count and reward
        plt.subplot(2, 2, 4)
        plt.scatter(asset_counts, nerf_rewards, alpha=0.6)
        plt.xlabel('Assets Used')
        plt.ylabel('NeRF Reward')
        plt.title('Asset Count vs NeRF Reward')
        plt.grid(True, alpha=0.3)
        
        plt.tight_layout()
        
        save_path = save_dir / "nerf_usage.png"
        plt.savefig(save_path, dpi=150, bbox_inches='tight')
        plt.close()
        
        return str(save_path)
    
    def _create_performance_plot(self, save_dir: Path, performance_keys: List[str]) -> str:
        """Create performance metrics plot."""
        
        episodes = list(self.training_metrics['episode'])
        
        n_metrics = len(performance_keys)
        cols = min(3, n_metrics)
        rows = int(np.ceil(n_metrics / cols))
        
        plt.figure(figsize=(cols * 4, rows * 3))
        
        for i, key in enumerate(performance_keys):
            plt.subplot(rows, cols, i + 1)
            
            values = list(self.training_metrics[key])
            plt.plot(episodes, values, linewidth=2)
            
            # Add moving average
            if len(values) > 10:
                window = min(20, len(values) // 4)
                moving_avg = np.convolve(values, np.ones(window)/window, mode='valid')
                plt.plot(episodes[window-1:], moving_avg, linewidth=2, alpha=0.8)
            
            plt.xlabel('Episode')
            plt.ylabel(key.replace('performance_', '').replace('_', ' ').title())
            plt.title(f'Performance: {key.replace("performance_", "").replace("_", " ").title()}')
            plt.grid(True, alpha=0.3)
        
        plt.tight_layout()
        
        save_path = save_dir / "performance_metrics.png"
        plt.savefig(save_path, dpi=150, bbox_inches='tight')
        plt.close()
        
        return str(save_path)
    
    def _create_curriculum_plot(self, save_dir: Path) -> str:
        """Create curriculum progression plot."""
        
        episodes = list(self.training_metrics['episode'])
        difficulties = list(self.training_metrics['difficulty'])
        rewards = list(self.training_metrics['total_reward'])
        
        plt.figure(figsize=(12, 6))
        
        # Difficulty progression
        plt.subplot(1, 2, 1)
        plt.plot(episodes, difficulties, linewidth=2, color='blue', label='Difficulty')
        plt.xlabel('Episode')
        plt.ylabel('Difficulty Level')
        plt.title('Curriculum Difficulty Progression')
        plt.ylim(0, 1.1)
        plt.legend()
        plt.grid(True, alpha=0.3)
        
        # Difficulty vs Reward correlation
        plt.subplot(1, 2, 2)
        plt.scatter(difficulties, rewards, alpha=0.6)
        plt.xlabel('Difficulty Level')
        plt.ylabel('Total Reward')
        plt.title('Difficulty vs Reward Correlation')
        plt.grid(True, alpha=0.3)
        
        # Add trend line
        if len(difficulties) > 1:
            z = np.polyfit(difficulties, rewards, 1)
            p = np.poly1d(z)
            plt.plot(sorted(difficulties), p(sorted(difficulties)), "r--", alpha=0.8, label='Trend')
            plt.legend()
        
        plt.tight_layout()
        
        save_path = save_dir / "curriculum_progression.png"
        plt.savefig(save_path, dpi=150, bbox_inches='tight')
        plt.close()
        
        return str(save_path)
    
    def _create_hitl_plot(self, save_dir: Path) -> str:
        """Create HITL feedback plot."""
        
        episodes = list(self.training_metrics['episode'])
        ratings = list(self.training_metrics['hitl_rating'])
        
        # Filter out None values
        valid_data = [(e, r) for e, r in zip(episodes, ratings) if r is not None]
        if not valid_data:
            return ""
        
        valid_episodes, valid_ratings = zip(*valid_data)
        
        plt.figure(figsize=(12, 6))
        
        # Rating progression
        plt.subplot(1, 2, 1)
        plt.plot(valid_episodes, valid_ratings, 'o-', linewidth=2, markersize=6)
        plt.xlabel('Episode')
        plt.ylabel('HITL Rating')
        plt.title('Human Feedback Progression')
        plt.ylim(0, 11)
        plt.grid(True, alpha=0.3)
        
        # Rating distribution
        plt.subplot(1, 2, 2)
        plt.hist(valid_ratings, bins=range(1, 12), alpha=0.7, edgecolor='black')
        plt.xlabel('Rating')
        plt.ylabel('Frequency')
        plt.title('HITL Rating Distribution')
        plt.xticks(range(1, 11))
        plt.grid(True, alpha=0.3)
        
        plt.tight_layout()
        
        save_path = save_dir / "hitl_feedback.png"
        plt.savefig(save_path, dpi=150, bbox_inches='tight')
        plt.close()
        
        return str(save_path)
    
    def _check_performance_alerts(self, episode_data: Dict[str, Any]):
        """Check for performance issues and generate alerts."""
        
        if not self.config.enable_alerts:
            return
        
        current_time = time.time()
        
        # Check reward performance
        if len(self.training_metrics['total_reward']) >= 20:
            recent_rewards = list(self.training_metrics['total_reward'])[-20:]
            avg_reward = np.mean(recent_rewards)
            
            if avg_reward < self.config.performance_threshold:
                alert = {
                    'type': 'low_performance',
                    'message': f'Average reward ({avg_reward:.3f}) below threshold ({self.config.performance_threshold})',
                    'timestamp': current_time,
                    'episode': episode_data.get('episode', 0),
                    'severity': 'warning'
                }
                self.performance_alerts.append(alert)
                logger.warning(alert['message'])
        
        # Check memory usage (placeholder - would need actual memory monitoring)
        # This would be implemented with psutil or similar
        
        # Check for training stagnation
        if len(self.training_metrics['total_reward']) >= 50:
            recent_rewards = list(self.training_metrics['total_reward'])[-50:]
            reward_variance = np.var(recent_rewards)
            
            if reward_variance < 0.01:  # Very low variance indicates stagnation
                alert = {
                    'type': 'training_stagnation',
                    'message': f'Training appears stagnant (reward variance: {reward_variance:.6f})',
                    'timestamp': current_time,
                    'episode': episode_data.get('episode', 0),
                    'severity': 'info'
                }
                self.performance_alerts.append(alert)
                logger.info(alert['message'])
    
    def _start_dashboard(self):
        """Start the web dashboard for real-time monitoring."""
        
        try:
            from flask import Flask, render_template_string, jsonify
            
            self.dashboard_app = Flask(__name__)
            
            @self.dashboard_app.route('/')
            def dashboard():
                return render_template_string(self._get_dashboard_template())
            
            @self.dashboard_app.route('/api/metrics')
            def get_metrics():
                return jsonify(self._get_dashboard_metrics())
            
            @self.dashboard_app.route('/api/alerts')
            def get_alerts():
                return jsonify(self.performance_alerts[-10:])  # Last 10 alerts
            
            # Start dashboard in separate thread
            self.dashboard_thread = threading.Thread(
                target=lambda: self.dashboard_app.run(
                    host='0.0.0.0',
                    port=self.config.dashboard_port,
                    debug=False,
                    use_reloader=False
                ),
                daemon=True
            )
            self.dashboard_thread.start()
            
            logger.info(f"Dashboard started on port {self.config.dashboard_port}")
            
        except ImportError:
            logger.warning("Flask not available, dashboard disabled")
        except Exception as e:
            logger.error(f"Failed to start dashboard: {e}")
    
    def _get_dashboard_metrics(self) -> Dict[str, Any]:
        """Get metrics for dashboard API."""
        
        metrics = {}
        
        for key, values in self.training_metrics.items():
            if values:
                metrics[key] = {
                    'current': values[-1] if values else 0,
                    'history': list(values)[-100:],  # Last 100 values
                    'avg': np.mean(values) if values else 0,
                    'std': np.std(values) if len(values) > 1 else 0
                }
        
        return metrics
    
    def _get_dashboard_template(self) -> str:
        """Get HTML template for dashboard."""
        
        return '''
<!DOCTYPE html>
<html>
<head>
    <title>RL Training Dashboard - Version 5 BETA 1</title>
    <script src="https://cdn.plot.ly/plotly-latest.min.js"></script>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }
        .container { max-width: 1200px; margin: 0 auto; }
        .header { text-align: center; margin-bottom: 30px; }
        .metrics-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px; }
        .metric-card { background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        .metric-value { font-size: 2em; font-weight: bold; color: #2196F3; }
        .metric-label { color: #666; margin-bottom: 10px; }
        .chart { height: 300px; margin-top: 15px; }
        .alerts { background: #fff3cd; border: 1px solid #ffeaa7; padding: 15px; border-radius: 8px; margin-top: 20px; }
        .alert-item { margin: 5px 0; padding: 5px; background: #fff; border-radius: 4px; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🎮 RL Training Dashboard - Version 5 BETA 1</h1>
            <p>Real-time monitoring of training progress</p>
        </div>
        
        <div class="metrics-grid">
            <div class="metric-card">
                <div class="metric-label">Current Episode</div>
                <div class="metric-value" id="current-episode">-</div>
            </div>
            
            <div class="metric-card">
                <div class="metric-label">Latest Reward</div>
                <div class="metric-value" id="latest-reward">-</div>
            </div>
            
            <div class="metric-card">
                <div class="metric-label">Success Rate</div>
                <div class="metric-value" id="success-rate">-</div>
            </div>
            
            <div class="metric-card">
                <div class="metric-label">NeRF Assets Used</div>
                <div class="metric-value" id="nerf-assets">-</div>
            </div>
        </div>
        
        <div class="metrics-grid" style="margin-top: 30px;">
            <div class="metric-card">
                <h3>Reward Progression</h3>
                <div id="reward-chart" class="chart"></div>
            </div>
            
            <div class="metric-card">
                <h3>Success Rate</h3>
                <div id="success-chart" class="chart"></div>
            </div>
            
            <div class="metric-card">
                <h3>Difficulty Progression</h3>
                <div id="difficulty-chart" class="chart"></div>
            </div>
            
            <div class="metric-card">
                <h3>NeRF Usage</h3>
                <div id="nerf-chart" class="chart"></div>
            </div>
        </div>
        
        <div class="alerts" id="alerts-section" style="display: none;">
            <h3>Recent Alerts</h3>
            <div id="alerts-list"></div>
        </div>
    </div>

    <script>
        function updateDashboard() {
            fetch('/api/metrics')
                .then(response => response.json())
                .then(data => {
                    // Update metric cards
                    if (data.episode) {
                        document.getElementById('current-episode').textContent = data.episode.current || '-';
                    }
                    if (data.total_reward) {
                        document.getElementById('latest-reward').textContent = (data.total_reward.current || 0).toFixed(2);
                    }
                    if (data.success_rate) {
                        const successRate = ((data.success_rate.avg || 0) * 100).toFixed(1) + '%';
                        document.getElementById('success-rate').textContent = successRate;
                    }
                    if (data.nerf_asset_count) {
                        document.getElementById('nerf-assets').textContent = data.nerf_asset_count.current || '-';
                    }
                    
                    // Update charts
                    updateChart('reward-chart', data.total_reward, 'Total Reward');
                    updateChart('success-chart', data.success_rate, 'Success Rate');
                    updateChart('difficulty-chart', data.difficulty, 'Difficulty');
                    updateChart('nerf-chart', data.nerf_asset_count, 'NeRF Assets');
                })
                .catch(error => console.error('Error updating dashboard:', error));
            
            // Update alerts
            fetch('/api/alerts')
                .then(response => response.json())
                .then(alerts => {
                    const alertsSection = document.getElementById('alerts-section');
                    const alertsList = document.getElementById('alerts-list');
                    
                    if (alerts.length > 0) {
                        alertsSection.style.display = 'block';
                        alertsList.innerHTML = alerts.map(alert => 
                            `<div class="alert-item">
                                <strong>${alert.type}:</strong> ${alert.message}
                                <small>(Episode ${alert.episode})</small>
                            </div>`
                        ).join('');
                    } else {
                        alertsSection.style.display = 'none';
                    }
                })
                .catch(error => console.error('Error updating alerts:', error));
        }
        
        function updateChart(elementId, data, title) {
            if (!data || !data.history) return;
            
            const trace = {
                x: Array.from({length: data.history.length}, (_, i) => i),
                y: data.history,
                type: 'scatter',
                mode: 'lines',
                line: {color: '#2196F3', width: 2}
            };
            
            const layout = {
                title: title,
                xaxis: {title: 'Episode'},
                yaxis: {title: title},
                margin: {l: 50, r: 20, t: 40, b: 40}
            };
            
            Plotly.newPlot(elementId, [trace], layout, {responsive: true});
        }
        
        // Update dashboard every 2 seconds
        setInterval(updateDashboard, 2000);
        updateDashboard(); // Initial update
    </script>
</body>
</html>
        '''
    
    def get_visualization_statistics(self) -> Dict[str, Any]:
        """Get comprehensive visualization statistics."""
        
        stats = {
            'total_metrics_tracked': len(self.training_metrics),
            'total_data_points': sum(len(values) for values in self.training_metrics.values()),
            'render_queue_size': len(self.render_queue),
            'active_render_workers': len(self.render_threads),
            'total_alerts': len(self.performance_alerts),
            'output_directory': str(self.output_dir),
            'tensorboard_enabled': self.tensorboard_writer is not None,
            'wandb_enabled': self.wandb_run is not None,
            'dashboard_enabled': self.dashboard_app is not None
        }
        
        # Add metric summaries
        for key, values in self.training_metrics.items():
            if values:
                stats[f'{key}_summary'] = {
                    'count': len(values),
                    'latest': values[-1],
                    'avg': np.mean(values),
                    'std': np.std(values) if len(values) > 1 else 0
                }
        
        return stats
    
    def cleanup(self):
        """Cleanup visualization resources."""
        
        # Close logging systems
        if self.tensorboard_writer:
            self.tensorboard_writer.close()
        
        if self.wandb_run:
            wandb.finish()
        
        # Clear render queue
        with self.render_lock:
            self.render_queue.clear()
        
        logger.info("Visualization Manager cleanup completed")

# Example usage
if __name__ == "__main__":
    config = VisualizationConfig(
        enable_tensorboard=True,
        enable_wandb=False,  # Set to True if WandB is configured
        enable_dashboard=True
    )
    
    viz_manager = VisualizationManager(config)
    
    # Simulate training updates
    for episode in range(100):
        episode_data = {
            'episode': episode,
            'total_reward': np.random.normal(10 + episode * 0.1, 2),
            'steps': np.random.randint(100, 300),
            'success': np.random.random() < (0.3 + episode * 0.005),
            'difficulty': min(0.1 + episode * 0.01, 1.0),
            'nerf_assets_used': set(np.random.choice(['asset1', 'asset2', 'asset3'], 
                                                   size=np.random.randint(0, 4), replace=False)),
            'nerf_rewards': [np.random.uniform(0, 2) for _ in range(np.random.randint(0, 5))],
            'performance_metrics': {
                'avg_reward_per_step': np.random.uniform(0.05, 0.15),
                'nerf_reward_ratio': np.random.uniform(0.1, 0.3),
                'fps': np.random.uniform(45, 75)
            }
        }
        
        # Add HITL rating occasionally
        if episode % 20 == 0:
            episode_data['hitl_rating'] = np.random.randint(5, 10)
        
        viz_manager.update_metrics(episode_data)
        
        if episode % 10 == 0:
            print(f"Episode {episode}: Updated visualization metrics")
    
    # Generate plots
    plots = viz_manager.generate_training_plots()
    print(f"Generated plots: {list(plots.keys())}")
    
    # Get statistics
    stats = viz_manager.get_visualization_statistics()
    print(f"Visualization statistics: {stats}")
    
    print(f"Dashboard available at: http://localhost:{config.dashboard_port}")
    
    # Cleanup
    viz_manager.cleanup()

