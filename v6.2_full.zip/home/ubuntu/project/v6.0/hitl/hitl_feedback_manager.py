"""
Human-in-the-Loop (HITL) Feedback Manager for Version 5 BETA 1

This module provides comprehensive human feedback collection and integration
for the RL training system, enabling users to rate outputs and provide
suggestions that directly influence training.

Key features:
- CLI-based feedback collection
- Web UI for enhanced user experience
- CSV logging with comprehensive data tracking
- Real-time feedback integration into training
- Feedback analysis and trend detection
- Automated feedback request scheduling
"""

import os
import csv
import json
import time
import threading
import logging
from typing import Dict, List, Any, Optional, Callable, Tuple
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from pathlib import Path
from collections import defaultdict, deque
import numpy as np
from flask import Flask, request, jsonify, render_template_string
import webbrowser
from contextlib import contextmanager

logger = logging.getLogger(__name__)

@dataclass
class FeedbackEntry:
    """Structure for a single feedback entry."""
    episode: int
    timestamp: datetime
    rating: int  # 1-10 scale
    comments: str
    suggestions: str
    scene_description: str
    performance_metrics: Dict[str, float]
    asset_info: Dict[str, Any]
    response_time: float  # Time taken to provide feedback
    feedback_source: str  # 'cli' or 'web'

@dataclass
class HITLConfig:
    """Configuration for HITL feedback system."""
    feedback_frequency: int = 100  # Every N episodes
    enable_web_ui: bool = True
    web_ui_port: int = 5001
    csv_file_path: str = "hitl_feedback_v5.csv"
    
    # Feedback collection settings
    max_wait_time: float = 300.0  # 5 minutes max wait
    auto_skip_threshold: float = 60.0  # Auto-skip after 1 minute
    enable_auto_skip: bool = True
    
    # Rating scale settings
    rating_min: int = 1
    rating_max: int = 10
    rating_labels: Dict[int, str] = field(default_factory=lambda: {
        1: "Very Poor", 2: "Poor", 3: "Below Average", 4: "Slightly Below Average",
        5: "Average", 6: "Slightly Above Average", 7: "Good", 8: "Very Good",
        9: "Excellent", 10: "Outstanding"
    })
    
    # Analysis settings
    trend_analysis_window: int = 50
    feedback_influence_weight: float = 0.1

class HITLFeedbackManager:
    """
    Comprehensive HITL feedback management system.
    
    Handles both CLI and web-based feedback collection, with automatic
    scheduling, data logging, and integration with the training system.
    """
    
    def __init__(self, config: Optional[HITLConfig] = None):
        self.config = config or HITLConfig()
        
        # Feedback storage
        self.feedback_history: List[FeedbackEntry] = []
        self.pending_feedback_requests: deque = deque()
        self.feedback_statistics: Dict[str, Any] = defaultdict(float)
        
        # Web UI components
        self.web_app: Optional[Flask] = None
        self.web_thread: Optional[threading.Thread] = None
        self.current_feedback_request: Optional[Dict[str, Any]] = None
        self.feedback_received_event = threading.Event()
        
        # Analysis components
        self.rating_trends: deque = deque(maxlen=self.config.trend_analysis_window)
        self.feedback_influence_history: List[float] = []
        
        # Initialize CSV file
        self._initialize_csv_file()
        
        # Start web UI if enabled
        if self.config.enable_web_ui:
            self._start_web_ui()
        
        logger.info("HITL Feedback Manager V5 initialized")
    
    def _initialize_csv_file(self):
        """Initialize CSV file with headers if it doesn't exist."""
        csv_path = Path(self.config.csv_file_path)
        
        if not csv_path.exists():
            with open(csv_path, 'w', newline='', encoding='utf-8') as csvfile:
                fieldnames = [
                    'episode', 'timestamp', 'rating', 'comments', 'suggestions',
                    'scene_description', 'performance_metrics', 'asset_info',
                    'response_time', 'feedback_source', 'training_metrics'
                ]
                writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
                writer.writeheader()
            
            logger.info(f"Initialized HITL feedback CSV: {csv_path}")
    
    def should_collect_feedback(self, episode: int) -> bool:
        """Determine if feedback should be collected for this episode."""
        return episode % self.config.feedback_frequency == 0
    
    def collect_feedback(self, episode_data: Dict[str, Any]) -> Optional[FeedbackEntry]:
        """
        Collect feedback for an episode using the configured method.
        
        Args:
            episode_data: Complete episode data including metrics and visuals
            
        Returns:
            FeedbackEntry if feedback was collected, None otherwise
        """
        
        episode = episode_data.get('episode', 0)
        
        logger.info(f"Collecting HITL feedback for episode {episode}")
        
        # Prepare feedback request
        feedback_request = self._prepare_feedback_request(episode_data)
        
        # Try web UI first, fall back to CLI
        feedback_entry = None
        
        if self.config.enable_web_ui and self.web_app:
            feedback_entry = self._collect_web_feedback(feedback_request)
        
        if not feedback_entry:
            feedback_entry = self._collect_cli_feedback(feedback_request)
        
        if feedback_entry:
            self._process_feedback(feedback_entry)
            return feedback_entry
        
        return None
    
    def _prepare_feedback_request(self, episode_data: Dict[str, Any]) -> Dict[str, Any]:
        """Prepare a structured feedback request."""
        return {
            'episode': episode_data.get('episode', 0),
            'total_reward': episode_data.get('total_reward', 0),
            'steps': episode_data.get('steps', 0),
            'nerf_assets_used': list(episode_data.get('nerf_assets_used', set())),
            'performance_metrics': episode_data.get('performance_metrics', {}),
            'scene_description': self._generate_scene_description(episode_data),
            'visual_summary': episode_data.get('visual_summary', 'No visual data available'),
            'timestamp': datetime.now()
        }
    
    def _generate_scene_description(self, episode_data: Dict[str, Any]) -> str:
        """Generate a human-readable scene description."""
        reward = episode_data.get('total_reward', 0)
        steps = episode_data.get('steps', 0)
        assets = episode_data.get('nerf_assets_used', set())
        
        description = f"Episode with {steps} steps, total reward: {reward:.2f}"
        
        if assets:
            description += f", using {len(assets)} NeRF assets: {', '.join(list(assets)[:3])}"
            if len(assets) > 3:
                description += f" and {len(assets) - 3} more"
        
        return description
    
    def _collect_cli_feedback(self, feedback_request: Dict[str, Any]) -> Optional[FeedbackEntry]:
        """Collect feedback via command line interface."""
        try:
            print("\n" + "="*60)
            print("HUMAN-IN-THE-LOOP FEEDBACK REQUEST")
            print("="*60)
            print(f"Episode: {feedback_request['episode']}")
            print(f"Scene: {feedback_request['scene_description']}")
            print(f"Performance: {feedback_request['performance_metrics']}")
            print("-"*60)
            
            start_time = time.time()
            
            # Get rating
            while True:
                try:
                    rating_input = input(f"Rate this episode (1-10, or 's' to skip): ").strip()
                    
                    if rating_input.lower() == 's':
                        print("Feedback skipped.")
                        return None
                    
                    rating = int(rating_input)
                    if self.config.rating_min <= rating <= self.config.rating_max:
                        break
                    else:
                        print(f"Please enter a rating between {self.config.rating_min} and {self.config.rating_max}")
                except ValueError:
                    print("Please enter a valid number or 's' to skip")
            
            # Get comments
            comments = input("Comments (optional): ").strip()
            
            # Get suggestions
            suggestions = input("Suggestions for improvement (optional): ").strip()
            
            response_time = time.time() - start_time
            
            # Create feedback entry
            feedback_entry = FeedbackEntry(
                episode=feedback_request['episode'],
                timestamp=datetime.now(),
                rating=rating,
                comments=comments,
                suggestions=suggestions,
                scene_description=feedback_request['scene_description'],
                performance_metrics=feedback_request['performance_metrics'],
                asset_info={'assets_used': feedback_request['nerf_assets_used']},
                response_time=response_time,
                feedback_source='cli'
            )
            
            print(f"Feedback recorded! Rating: {rating} ({self.config.rating_labels.get(rating, 'Unknown')})")
            print("="*60)
            
            return feedback_entry
            
        except KeyboardInterrupt:
            print("\nFeedback collection interrupted.")
            return None
        except Exception as e:
            logger.error(f"Error collecting CLI feedback: {e}")
            return None
    
    def _start_web_ui(self):
        """Start the web UI for feedback collection."""
        try:
            self.web_app = Flask(__name__)
            self._setup_web_routes()
            
            # Start web server in separate thread
            self.web_thread = threading.Thread(
                target=self._run_web_server,
                daemon=True
            )
            self.web_thread.start()
            
            logger.info(f"HITL Web UI started on port {self.config.web_ui_port}")
            
        except Exception as e:
            logger.error(f"Failed to start web UI: {e}")
            self.config.enable_web_ui = False
    
    def _setup_web_routes(self):
        """Setup web UI routes."""
        
        @self.web_app.route('/')
        def index():
            return render_template_string(self._get_web_ui_template())
        
        @self.web_app.route('/api/current_request')
        def get_current_request():
            if self.current_feedback_request:
                return jsonify(self.current_feedback_request)
            return jsonify({'status': 'no_request'})
        
        @self.web_app.route('/api/submit_feedback', methods=['POST'])
        def submit_feedback():
            try:
                data = request.json
                
                if not self.current_feedback_request:
                    return jsonify({'error': 'No active feedback request'}), 400
                
                # Create feedback entry
                feedback_entry = FeedbackEntry(
                    episode=self.current_feedback_request['episode'],
                    timestamp=datetime.now(),
                    rating=int(data['rating']),
                    comments=data.get('comments', ''),
                    suggestions=data.get('suggestions', ''),
                    scene_description=self.current_feedback_request['scene_description'],
                    performance_metrics=self.current_feedback_request['performance_metrics'],
                    asset_info={'assets_used': self.current_feedback_request['nerf_assets_used']},
                    response_time=data.get('response_time', 0),
                    feedback_source='web'
                )
                
                # Store feedback and signal completion
                self.current_feedback_entry = feedback_entry
                self.feedback_received_event.set()
                
                return jsonify({'status': 'success'})
                
            except Exception as e:
                logger.error(f"Error processing web feedback: {e}")
                return jsonify({'error': str(e)}), 500
        
        @self.web_app.route('/api/skip_feedback', methods=['POST'])
        def skip_feedback():
            self.current_feedback_request = None
            self.feedback_received_event.set()
            return jsonify({'status': 'skipped'})
        
        @self.web_app.route('/api/feedback_history')
        def get_feedback_history():
            history = []
            for entry in self.feedback_history[-20:]:  # Last 20 entries
                history.append({
                    'episode': entry.episode,
                    'timestamp': entry.timestamp.isoformat(),
                    'rating': entry.rating,
                    'comments': entry.comments,
                    'source': entry.feedback_source
                })
            return jsonify(history)
    
    def _run_web_server(self):
        """Run the web server."""
        try:
            self.web_app.run(
                host='0.0.0.0',
                port=self.config.web_ui_port,
                debug=False,
                use_reloader=False
            )
        except Exception as e:
            logger.error(f"Web server error: {e}")
    
    def _collect_web_feedback(self, feedback_request: Dict[str, Any]) -> Optional[FeedbackEntry]:
        """Collect feedback via web UI."""
        try:
            # Set current request
            self.current_feedback_request = feedback_request
            self.current_feedback_entry = None
            self.feedback_received_event.clear()
            
            # Open browser to feedback page
            web_url = f"http://localhost:{self.config.web_ui_port}"
            try:
                webbrowser.open(web_url)
                print(f"\nFeedback UI opened in browser: {web_url}")
                print("Please provide feedback in the web interface...")
            except:
                print(f"\nPlease open your browser and go to: {web_url}")
            
            # Wait for feedback with timeout
            if self.feedback_received_event.wait(timeout=self.config.max_wait_time):
                feedback_entry = getattr(self, 'current_feedback_entry', None)
                self.current_feedback_request = None
                return feedback_entry
            else:
                print("Feedback timeout - skipping to CLI")
                self.current_feedback_request = None
                return None
                
        except Exception as e:
            logger.error(f"Error collecting web feedback: {e}")
            return None
    
    def _process_feedback(self, feedback_entry: FeedbackEntry):
        """Process and store feedback entry."""
        # Add to history
        self.feedback_history.append(feedback_entry)
        
        # Update statistics
        self._update_feedback_statistics(feedback_entry)
        
        # Save to CSV
        self._save_feedback_to_csv(feedback_entry)
        
        # Update trends
        self.rating_trends.append(feedback_entry.rating)
        
        logger.info(f"Processed feedback: Episode {feedback_entry.episode}, Rating {feedback_entry.rating}")
    
    def _update_feedback_statistics(self, feedback_entry: FeedbackEntry):
        """Update feedback statistics."""
        self.feedback_statistics['total_feedback'] += 1
        self.feedback_statistics['total_rating'] += feedback_entry.rating
        self.feedback_statistics['avg_rating'] = (
            self.feedback_statistics['total_rating'] / 
            self.feedback_statistics['total_feedback']
        )
        
        # Update source statistics
        source_key = f'{feedback_entry.feedback_source}_count'
        self.feedback_statistics[source_key] += 1
        
        # Update response time statistics
        if feedback_entry.response_time > 0:
            self.feedback_statistics['total_response_time'] += feedback_entry.response_time
            self.feedback_statistics['avg_response_time'] = (
                self.feedback_statistics['total_response_time'] / 
                self.feedback_statistics['total_feedback']
            )
    
    def _save_feedback_to_csv(self, feedback_entry: FeedbackEntry):
        """Save feedback entry to CSV file."""
        try:
            with open(self.config.csv_file_path, 'a', newline='', encoding='utf-8') as csvfile:
                fieldnames = [
                    'episode', 'timestamp', 'rating', 'comments', 'suggestions',
                    'scene_description', 'performance_metrics', 'asset_info',
                    'response_time', 'feedback_source', 'training_metrics'
                ]
                writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
                
                writer.writerow({
                    'episode': feedback_entry.episode,
                    'timestamp': feedback_entry.timestamp.isoformat(),
                    'rating': feedback_entry.rating,
                    'comments': feedback_entry.comments,
                    'suggestions': feedback_entry.suggestions,
                    'scene_description': feedback_entry.scene_description,
                    'performance_metrics': json.dumps(feedback_entry.performance_metrics),
                    'asset_info': json.dumps(feedback_entry.asset_info),
                    'response_time': feedback_entry.response_time,
                    'feedback_source': feedback_entry.feedback_source,
                    'training_metrics': json.dumps({})  # Placeholder for additional metrics
                })
                
        except Exception as e:
            logger.error(f"Error saving feedback to CSV: {e}")
    
    def get_feedback_influence_score(self) -> float:
        """Calculate current feedback influence on training."""
        if not self.rating_trends:
            return 0.0
        
        # Calculate trend
        recent_ratings = list(self.rating_trends)
        if len(recent_ratings) < 2:
            return 0.0
        
        # Simple trend calculation
        trend = np.polyfit(range(len(recent_ratings)), recent_ratings, 1)[0]
        
        # Convert to influence score (-1 to 1)
        influence_score = np.tanh(trend * self.config.feedback_influence_weight)
        
        self.feedback_influence_history.append(influence_score)
        
        return influence_score
    
    def get_feedback_statistics(self) -> Dict[str, Any]:
        """Get comprehensive feedback statistics."""
        stats = dict(self.feedback_statistics)
        
        if self.rating_trends:
            stats['rating_trend'] = {
                'current_avg': np.mean(list(self.rating_trends)),
                'recent_trend': self.get_feedback_influence_score(),
                'rating_variance': np.var(list(self.rating_trends)),
                'total_entries': len(self.rating_trends)
            }
        
        return stats
    
    def _get_web_ui_template(self) -> str:
        """Get the HTML template for the web UI."""
        return '''
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HITL Feedback - Version 5 BETA 1</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            min-height: 100vh;
        }
        .container {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 8px 32px rgba(31, 38, 135, 0.37);
        }
        h1 {
            text-align: center;
            margin-bottom: 30px;
            font-size: 2.5em;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
        }
        .episode-info {
            background: rgba(255, 255, 255, 0.1);
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 30px;
        }
        .rating-section {
            margin: 30px 0;
        }
        .rating-buttons {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            justify-content: center;
            margin: 20px 0;
        }
        .rating-btn {
            padding: 15px 20px;
            border: none;
            border-radius: 8px;
            background: rgba(255, 255, 255, 0.2);
            color: white;
            cursor: pointer;
            transition: all 0.3s ease;
            font-size: 16px;
            font-weight: bold;
        }
        .rating-btn:hover {
            background: rgba(255, 255, 255, 0.3);
            transform: translateY(-2px);
        }
        .rating-btn.selected {
            background: #4CAF50;
            box-shadow: 0 4px 15px rgba(76, 175, 80, 0.4);
        }
        .form-group {
            margin: 20px 0;
        }
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
        }
        textarea, input {
            width: 100%;
            padding: 12px;
            border: none;
            border-radius: 8px;
            background: rgba(255, 255, 255, 0.2);
            color: white;
            font-size: 16px;
        }
        textarea::placeholder, input::placeholder {
            color: rgba(255, 255, 255, 0.7);
        }
        .button-group {
            display: flex;
            gap: 15px;
            justify-content: center;
            margin-top: 30px;
        }
        .btn {
            padding: 15px 30px;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        .btn-primary {
            background: #4CAF50;
            color: white;
        }
        .btn-secondary {
            background: rgba(255, 255, 255, 0.2);
            color: white;
        }
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(0,0,0,0.2);
        }
        .loading {
            text-align: center;
            font-size: 18px;
            margin: 50px 0;
        }
        .history {
            margin-top: 40px;
            background: rgba(255, 255, 255, 0.1);
            padding: 20px;
            border-radius: 10px;
        }
        .history-item {
            padding: 10px;
            margin: 10px 0;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 5px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🎮 HITL Feedback System</h1>
        <div id="content">
            <div class="loading">Loading feedback request...</div>
        </div>
    </div>

    <script>
        let currentRequest = null;
        let selectedRating = null;
        let startTime = Date.now();

        async function loadCurrentRequest() {
            try {
                const response = await fetch('/api/current_request');
                const data = await response.json();
                
                if (data.status === 'no_request') {
                    document.getElementById('content').innerHTML = `
                        <div class="loading">
                            <h2>No active feedback request</h2>
                            <p>Waiting for training episode to complete...</p>
                        </div>
                    `;
                    setTimeout(loadCurrentRequest, 2000);
                    return;
                }
                
                currentRequest = data;
                startTime = Date.now();
                renderFeedbackForm();
                
            } catch (error) {
                console.error('Error loading request:', error);
                setTimeout(loadCurrentRequest, 5000);
            }
        }

        function renderFeedbackForm() {
            const content = document.getElementById('content');
            content.innerHTML = `
                <div class="episode-info">
                    <h2>Episode ${currentRequest.episode}</h2>
                    <p><strong>Scene:</strong> ${currentRequest.scene_description}</p>
                    <p><strong>Total Reward:</strong> ${currentRequest.total_reward.toFixed(2)}</p>
                    <p><strong>Steps:</strong> ${currentRequest.steps}</p>
                    <p><strong>NeRF Assets:</strong> ${currentRequest.nerf_assets_used.join(', ') || 'None'}</p>
                </div>

                <div class="rating-section">
                    <h3>Rate this episode (1-10):</h3>
                    <div class="rating-buttons">
                        ${Array.from({length: 10}, (_, i) => i + 1).map(rating => 
                            `<button class="rating-btn" onclick="selectRating(${rating})">${rating}</button>`
                        ).join('')}
                    </div>
                    <div id="rating-label" style="text-align: center; margin-top: 10px; font-style: italic;"></div>
                </div>

                <div class="form-group">
                    <label for="comments">Comments (optional):</label>
                    <textarea id="comments" rows="3" placeholder="What did you think about this episode?"></textarea>
                </div>

                <div class="form-group">
                    <label for="suggestions">Suggestions (optional):</label>
                    <textarea id="suggestions" rows="3" placeholder="How could the agent improve?"></textarea>
                </div>

                <div class="button-group">
                    <button class="btn btn-primary" onclick="submitFeedback()">Submit Feedback</button>
                    <button class="btn btn-secondary" onclick="skipFeedback()">Skip</button>
                </div>
            `;
        }

        function selectRating(rating) {
            selectedRating = rating;
            
            // Update button states
            document.querySelectorAll('.rating-btn').forEach(btn => {
                btn.classList.remove('selected');
            });
            event.target.classList.add('selected');
            
            // Update rating label
            const labels = {
                1: "Very Poor", 2: "Poor", 3: "Below Average", 4: "Slightly Below Average",
                5: "Average", 6: "Slightly Above Average", 7: "Good", 8: "Very Good",
                9: "Excellent", 10: "Outstanding"
            };
            document.getElementById('rating-label').textContent = labels[rating] || '';
        }

        async function submitFeedback() {
            if (!selectedRating) {
                alert('Please select a rating first!');
                return;
            }

            const responseTime = (Date.now() - startTime) / 1000;
            const comments = document.getElementById('comments').value;
            const suggestions = document.getElementById('suggestions').value;

            try {
                const response = await fetch('/api/submit_feedback', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        rating: selectedRating,
                        comments: comments,
                        suggestions: suggestions,
                        response_time: responseTime
                    })
                });

                if (response.ok) {
                    document.getElementById('content').innerHTML = `
                        <div class="loading">
                            <h2>✅ Feedback Submitted!</h2>
                            <p>Thank you for your feedback. Rating: ${selectedRating}</p>
                            <p>Waiting for next episode...</p>
                        </div>
                    `;
                    setTimeout(loadCurrentRequest, 3000);
                } else {
                    alert('Error submitting feedback. Please try again.');
                }
            } catch (error) {
                console.error('Error submitting feedback:', error);
                alert('Error submitting feedback. Please try again.');
            }
        }

        async function skipFeedback() {
            try {
                await fetch('/api/skip_feedback', { method: 'POST' });
                document.getElementById('content').innerHTML = `
                    <div class="loading">
                        <h2>Feedback Skipped</h2>
                        <p>Waiting for next episode...</p>
                    </div>
                `;
                setTimeout(loadCurrentRequest, 3000);
            } catch (error) {
                console.error('Error skipping feedback:', error);
            }
        }

        // Start loading
        loadCurrentRequest();
    </script>
</body>
</html>
        '''
    
    def cleanup(self):
        """Cleanup resources."""
        if self.web_thread and self.web_thread.is_alive():
            # Note: Flask server cleanup would need more sophisticated handling
            pass
        
        logger.info("HITL Feedback Manager cleanup completed")

# Example usage
if __name__ == "__main__":
    config = HITLConfig(
        feedback_frequency=10,  # Every 10 episodes for testing
        enable_web_ui=True
    )
    
    hitl_manager = HITLFeedbackManager(config)
    
    # Simulate episode data
    episode_data = {
        'episode': 100,
        'total_reward': 15.7,
        'steps': 250,
        'nerf_assets_used': {'medieval_tower', 'fire_effect'},
        'performance_metrics': {'fps': 65, 'render_time': 45}
    }
    
    # Collect feedback
    feedback = hitl_manager.collect_feedback(episode_data)
    
    if feedback:
        print(f"Collected feedback: Rating {feedback.rating}")
        print(f"Statistics: {hitl_manager.get_feedback_statistics()}")
    
    # Cleanup
    hitl_manager.cleanup()

