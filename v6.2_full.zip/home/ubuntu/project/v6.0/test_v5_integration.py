#!/usr/bin/env python3
"""
Comprehensive Test Suite for RL Training System Version 5 BETA 1

This script performs end-to-end testing of all system components to ensure
proper integration and functionality before final package creation.

Usage:
    python test_v5_integration.py --full-test
    python test_v5_integration.py --quick-test
    python test_v5_integration.py --component-test core
    python test_v5_integration.py --performance-test

Author: Manus AI Team
Version: 5.0.0-beta1
"""

import os
import sys
import json
import time
import logging
import traceback
import subprocess
from pathlib import Path
from typing import Dict, List, Any, Optional, Tuple
import tempfile
import shutil

# Add project root to path
project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class V5IntegrationTester:
    """
    Comprehensive integration tester for Version 5 BETA 1.
    
    Performs systematic testing of all components and their interactions
    to ensure the system is ready for production use.
    """
    
    def __init__(self):
        self.version = "5.0.0-beta1"
        self.test_results = {}
        self.failed_tests = []
        self.temp_dir = None
        
        # Test configuration
        self.test_config = {
            'quick_test_episodes': 5,
            'full_test_episodes': 50,
            'performance_test_episodes': 100,
            'timeout_seconds': 300,
            'memory_limit_mb': 2000
        }
        
        logger.info(f"V5 Integration Tester initialized for version {self.version}")
    
    def setup_test_environment(self):
        """Setup temporary test environment."""
        
        logger.info("Setting up test environment...")
        
        # Create temporary directory
        self.temp_dir = tempfile.mkdtemp(prefix="v5_test_")
        logger.info(f"Test directory: {self.temp_dir}")
        
        # Create test configuration
        test_config = {
            "version": "5.0.0-beta1",
            "training": {
                "episodes": self.test_config['quick_test_episodes'],
                "batch_size": 8,
                "learning_rate": 0.01,
                "save_frequency": 10
            },
            "nerf": {
                "enabled": True,
                "asset_directory": "assets/test_nerf",
                "max_assets_per_episode": 2
            },
            "hitl": {
                "enabled": True,
                "feedback_frequency": 5,
                "timeout_seconds": 5,
                "auto_feedback": True
            },
            "visualization": {
                "enabled": True,
                "dashboard_port": 5003,
                "tensorboard_enabled": False,
                "wandb_enabled": False
            },
            "robustness": {
                "enabled": True,
                "error_testing_enabled": True,
                "fault_injection": False
            },
            "output": {
                "base_directory": str(Path(self.temp_dir) / "outputs"),
                "models_directory": str(Path(self.temp_dir) / "models"),
                "logs_directory": str(Path(self.temp_dir) / "logs")
            }
        }
        
        # Save test configuration
        config_path = Path(self.temp_dir) / "test_config.json"
        with open(config_path, 'w') as f:
            json.dump(test_config, f, indent=2)
        
        # Create test directories
        for directory in test_config['output'].values():
            Path(directory).mkdir(parents=True, exist_ok=True)
        
        logger.info("Test environment setup completed")
        return config_path
    
    def test_imports(self) -> bool:
        """Test that all modules can be imported successfully."""
        
        logger.info("Testing module imports...")
        
        import_tests = [
            ('core.training_loop_v5', 'EnhancedTrainingLoop'),
            ('core.nerf_integration_v5', 'NeRFIntegrationManager'),
            ('core.reward_system_v5', 'RewardSystem'),
            ('core.curriculum_learning', 'CurriculumManager'),
            ('core.replay_buffer', 'EpisodicReplayBuffer'),
            ('hitl.hitl_feedback_manager', 'HITLFeedbackManager'),
            ('visualization.visualization_manager', 'VisualizationManager'),
            ('tests.robustness_testing', 'RobustnessTestingFramework'),
            ('main_v5', 'RLTrainingSystemV5')
        ]
        
        failed_imports = []
        
        for module_name, class_name in import_tests:
            try:
                module = __import__(module_name, fromlist=[class_name])
                getattr(module, class_name)
                logger.info(f"✓ Successfully imported {module_name}.{class_name}")
            except Exception as e:
                logger.error(f"✗ Failed to import {module_name}.{class_name}: {e}")
                failed_imports.append((module_name, class_name, str(e)))
        
        success = len(failed_imports) == 0
        self.test_results['imports'] = {
            'success': success,
            'total_tests': len(import_tests),
            'failed_imports': failed_imports
        }
        
        if not success:
            self.failed_tests.append('imports')
        
        return success
    
    def test_core_components(self) -> bool:
        """Test core training components."""
        
        logger.info("Testing core components...")
        
        try:
            from core.training_loop_v5 import EnhancedTrainingLoop, TrainingConfig
            from core.nerf_integration_v5 import NeRFIntegrationManager, NeRFConfig
            from core.reward_system_v5 import RewardSystem, RewardConfig
            from core.curriculum_learning import CurriculumManager, CurriculumConfig
            from core.replay_buffer import EpisodicReplayBuffer, ReplayBufferConfig
            
            # Test component initialization
            components_tested = {}
            
            # Training loop
            try:
                config = TrainingConfig(episodes=10, batch_size=4)
                training_loop = EnhancedTrainingLoop(config)
                components_tested['training_loop'] = True
                logger.info("✓ Training loop initialization successful")
            except Exception as e:
                components_tested['training_loop'] = False
                logger.error(f"✗ Training loop initialization failed: {e}")
            
            # NeRF manager
            try:
                nerf_config = NeRFConfig(asset_directory="test_assets")
                nerf_manager = NeRFIntegrationManager(nerf_config)
                components_tested['nerf_manager'] = True
                logger.info("✓ NeRF manager initialization successful")
            except Exception as e:
                components_tested['nerf_manager'] = False
                logger.error(f"✗ NeRF manager initialization failed: {e}")
            
            # Reward system
            try:
                reward_config = RewardConfig()
                reward_system = RewardSystem(reward_config)
                components_tested['reward_system'] = True
                logger.info("✓ Reward system initialization successful")
            except Exception as e:
                components_tested['reward_system'] = False
                logger.error(f"✗ Reward system initialization failed: {e}")
            
            # Curriculum manager
            try:
                curriculum_config = CurriculumConfig()
                curriculum_manager = CurriculumManager(curriculum_config)
                components_tested['curriculum_manager'] = True
                logger.info("✓ Curriculum manager initialization successful")
            except Exception as e:
                components_tested['curriculum_manager'] = False
                logger.error(f"✗ Curriculum manager initialization failed: {e}")
            
            # Replay buffer
            try:
                replay_config = ReplayBufferConfig(max_episodes=100)
                replay_buffer = EpisodicReplayBuffer(replay_config)
                components_tested['replay_buffer'] = True
                logger.info("✓ Replay buffer initialization successful")
            except Exception as e:
                components_tested['replay_buffer'] = False
                logger.error(f"✗ Replay buffer initialization failed: {e}")
            
            success = all(components_tested.values())
            self.test_results['core_components'] = {
                'success': success,
                'components': components_tested
            }
            
            if not success:
                self.failed_tests.append('core_components')
            
            return success
            
        except Exception as e:
            logger.error(f"Core components test failed: {e}")
            self.test_results['core_components'] = {
                'success': False,
                'error': str(e)
            }
            self.failed_tests.append('core_components')
            return False
    
    def test_hitl_system(self) -> bool:
        """Test HITL feedback system."""
        
        logger.info("Testing HITL system...")
        
        try:
            from hitl.hitl_feedback_manager import HITLFeedbackManager, HITLConfig
            
            # Test HITL manager initialization
            hitl_config = HITLConfig(
                feedback_frequency=5,
                timeout_seconds=1,
                auto_feedback=True
            )
            
            hitl_manager = HITLFeedbackManager(hitl_config)
            
            # Test feedback collection
            test_episode_data = {
                'episode': 1,
                'total_reward': 10.0,
                'success': True,
                'observations': [],
                'actions': []
            }
            
            # Test auto feedback (should not block)
            feedback = hitl_manager.collect_feedback(test_episode_data)
            
            success = feedback is not None
            self.test_results['hitl_system'] = {
                'success': success,
                'feedback_received': feedback is not None
            }
            
            if success:
                logger.info("✓ HITL system test successful")
            else:
                logger.error("✗ HITL system test failed")
                self.failed_tests.append('hitl_system')
            
            return success
            
        except Exception as e:
            logger.error(f"HITL system test failed: {e}")
            self.test_results['hitl_system'] = {
                'success': False,
                'error': str(e)
            }
            self.failed_tests.append('hitl_system')
            return False
    
    def test_visualization_system(self) -> bool:
        """Test visualization and monitoring system."""
        
        logger.info("Testing visualization system...")
        
        try:
            from visualization.visualization_manager import VisualizationManager, VisualizationConfig
            
            # Test visualization manager initialization
            viz_config = VisualizationConfig(
                enable_tensorboard=False,
                enable_wandb=False,
                enable_dashboard=False  # Disable to avoid port conflicts
            )
            
            viz_manager = VisualizationManager(viz_config)
            
            # Test metrics update
            test_episode_data = {
                'episode': 1,
                'total_reward': 15.0,
                'success': True,
                'nerf_assets_used': {'asset1', 'asset2'},
                'performance_metrics': {
                    'avg_reward_per_step': 0.1,
                    'nerf_reward_ratio': 0.2
                }
            }
            
            viz_manager.update_metrics(test_episode_data)
            
            # Test statistics retrieval
            stats = viz_manager.get_visualization_statistics()
            
            success = stats is not None and 'total_metrics_tracked' in stats
            self.test_results['visualization_system'] = {
                'success': success,
                'metrics_tracked': stats.get('total_metrics_tracked', 0) if stats else 0
            }
            
            if success:
                logger.info("✓ Visualization system test successful")
            else:
                logger.error("✗ Visualization system test failed")
                self.failed_tests.append('visualization_system')
            
            # Cleanup
            viz_manager.cleanup()
            
            return success
            
        except Exception as e:
            logger.error(f"Visualization system test failed: {e}")
            self.test_results['visualization_system'] = {
                'success': False,
                'error': str(e)
            }
            self.failed_tests.append('visualization_system')
            return False
    
    def test_robustness_framework(self) -> bool:
        """Test robustness and error handling framework."""
        
        logger.info("Testing robustness framework...")
        
        try:
            from tests.robustness_testing import RobustnessTestingFramework, RobustnessConfig, ErrorType
            
            # Test robustness framework initialization
            robustness_config = RobustnessConfig(
                enable_stress_testing=True,
                enable_fault_injection=False,
                test_frequency=10
            )
            
            robustness_framework = RobustnessTestingFramework(robustness_config)
            
            # Test error handling
            test_context = {'episode': 1, 'test_mode': True}
            
            recovery_success = robustness_framework.handle_error(
                ErrorType.IO_ERROR,
                "Test I/O error",
                test_context
            )
            
            # Test statistics
            stats = robustness_framework.get_robustness_statistics()
            
            success = stats is not None and 'total_errors' in stats
            self.test_results['robustness_framework'] = {
                'success': success,
                'recovery_success': recovery_success,
                'total_errors': stats.get('total_errors', 0) if stats else 0
            }
            
            if success:
                logger.info("✓ Robustness framework test successful")
            else:
                logger.error("✗ Robustness framework test failed")
                self.failed_tests.append('robustness_framework')
            
            # Cleanup
            robustness_framework.cleanup()
            
            return success
            
        except Exception as e:
            logger.error(f"Robustness framework test failed: {e}")
            self.test_results['robustness_framework'] = {
                'success': False,
                'error': str(e)
            }
            self.failed_tests.append('robustness_framework')
            return False
    
    def test_main_integration(self, config_path: str) -> bool:
        """Test main system integration."""
        
        logger.info("Testing main system integration...")
        
        try:
            from main_v5 import RLTrainingSystemV5
            
            # Initialize main system
            system = RLTrainingSystemV5(config_path=config_path)
            
            # Initialize components
            system.initialize_components()
            
            # Test system status
            status = system.get_system_status()
            
            # Check that all expected components are initialized
            expected_components = [
                'training_loop', 'reward_system', 'replay_buffer',
                'hitl_manager', 'visualization_manager', 'robustness_framework'
            ]
            
            components_initialized = all(
                status['components'].get(comp, False) for comp in expected_components
            )
            
            success = components_initialized and status['version'] == self.version
            self.test_results['main_integration'] = {
                'success': success,
                'version_correct': status['version'] == self.version,
                'components_initialized': components_initialized,
                'status': status
            }
            
            if success:
                logger.info("✓ Main integration test successful")
            else:
                logger.error("✗ Main integration test failed")
                self.failed_tests.append('main_integration')
            
            # Cleanup
            system.shutdown()
            
            return success
            
        except Exception as e:
            logger.error(f"Main integration test failed: {e}")
            self.test_results['main_integration'] = {
                'success': False,
                'error': str(e)
            }
            self.failed_tests.append('main_integration')
            return False
    
    def test_end_to_end_training(self, config_path: str) -> bool:
        """Test end-to-end training process."""
        
        logger.info("Testing end-to-end training...")
        
        try:
            from main_v5 import RLTrainingSystemV5
            
            # Initialize system
            system = RLTrainingSystemV5(config_path=config_path)
            system.initialize_components()
            
            # Run short training session
            start_time = time.time()
            
            # This would normally start training, but we'll simulate it
            # to avoid long test times
            test_episodes = 3
            
            for episode in range(test_episodes):
                # Simulate episode data
                episode_data = {
                    'episode': episode,
                    'total_reward': 10.0 + episode * 2,
                    'success': episode > 0,
                    'steps': 50 + episode * 10,
                    'nerf_assets_used': {'asset1', 'asset2'},
                    'performance_metrics': {
                        'avg_reward_per_step': 0.1 + episode * 0.01
                    }
                }
                
                # Update visualization
                if system.visualization_manager:
                    system.visualization_manager.update_metrics(episode_data)
                
                # Test robustness
                if system.robustness_framework:
                    system.robustness_framework.run_robustness_tests(episode, episode_data)
                
                time.sleep(0.1)  # Simulate episode time
            
            end_time = time.time()
            training_time = end_time - start_time
            
            # Get final status
            final_status = system.get_system_status()
            
            success = training_time < self.test_config['timeout_seconds']
            self.test_results['end_to_end_training'] = {
                'success': success,
                'training_time': training_time,
                'episodes_completed': test_episodes,
                'final_status': final_status
            }
            
            if success:
                logger.info(f"✓ End-to-end training test successful ({training_time:.2f}s)")
            else:
                logger.error("✗ End-to-end training test failed")
                self.failed_tests.append('end_to_end_training')
            
            # Cleanup
            system.shutdown()
            
            return success
            
        except Exception as e:
            logger.error(f"End-to-end training test failed: {e}")
            self.test_results['end_to_end_training'] = {
                'success': False,
                'error': str(e)
            }
            self.failed_tests.append('end_to_end_training')
            return False
    
    def test_performance(self) -> bool:
        """Test system performance metrics."""
        
        logger.info("Testing system performance...")
        
        try:
            import psutil
            import time
            
            # Memory usage test
            process = psutil.Process()
            initial_memory = process.memory_info().rss / 1024 / 1024  # MB
            
            # CPU usage test
            cpu_percent = psutil.cpu_percent(interval=1)
            
            # GPU memory test (if available)
            gpu_memory = 0
            try:
                import torch
                if torch.cuda.is_available():
                    gpu_memory = torch.cuda.memory_allocated() / 1024 / 1024
            except ImportError:
                pass
            
            # Performance criteria
            memory_ok = initial_memory < self.test_config['memory_limit_mb']
            cpu_ok = cpu_percent < 90  # Less than 90% CPU usage
            
            success = memory_ok and cpu_ok
            self.test_results['performance'] = {
                'success': success,
                'memory_usage_mb': initial_memory,
                'memory_limit_mb': self.test_config['memory_limit_mb'],
                'cpu_percent': cpu_percent,
                'gpu_memory_mb': gpu_memory,
                'memory_ok': memory_ok,
                'cpu_ok': cpu_ok
            }
            
            if success:
                logger.info(f"✓ Performance test successful (Memory: {initial_memory:.1f}MB, CPU: {cpu_percent:.1f}%)")
            else:
                logger.error("✗ Performance test failed")
                self.failed_tests.append('performance')
            
            return success
            
        except Exception as e:
            logger.error(f"Performance test failed: {e}")
            self.test_results['performance'] = {
                'success': False,
                'error': str(e)
            }
            self.failed_tests.append('performance')
            return False
    
    def run_quick_test(self) -> bool:
        """Run quick integration test suite."""
        
        logger.info("Running quick test suite...")
        
        # Setup test environment
        config_path = self.setup_test_environment()
        
        tests = [
            ('imports', self.test_imports),
            ('core_components', self.test_core_components),
            ('hitl_system', self.test_hitl_system),
            ('visualization_system', self.test_visualization_system),
            ('robustness_framework', self.test_robustness_framework),
            ('main_integration', lambda: self.test_main_integration(str(config_path))),
            ('performance', self.test_performance)
        ]
        
        passed_tests = 0
        total_tests = len(tests)
        
        for test_name, test_func in tests:
            logger.info(f"Running test: {test_name}")
            try:
                if test_func():
                    passed_tests += 1
                    logger.info(f"✓ {test_name} PASSED")
                else:
                    logger.error(f"✗ {test_name} FAILED")
            except Exception as e:
                logger.error(f"✗ {test_name} FAILED with exception: {e}")
        
        success_rate = passed_tests / total_tests
        overall_success = success_rate >= 0.8  # 80% pass rate required
        
        logger.info(f"Quick test results: {passed_tests}/{total_tests} tests passed ({success_rate:.1%})")
        
        return overall_success
    
    def run_full_test(self) -> bool:
        """Run comprehensive test suite."""
        
        logger.info("Running full test suite...")
        
        # Run quick tests first
        quick_success = self.run_quick_test()
        
        if not quick_success:
            logger.error("Quick tests failed, skipping full tests")
            return False
        
        # Setup for full tests
        config_path = self.setup_test_environment()
        
        # Additional full tests
        additional_tests = [
            ('end_to_end_training', lambda: self.test_end_to_end_training(str(config_path)))
        ]
        
        passed_additional = 0
        total_additional = len(additional_tests)
        
        for test_name, test_func in additional_tests:
            logger.info(f"Running full test: {test_name}")
            try:
                if test_func():
                    passed_additional += 1
                    logger.info(f"✓ {test_name} PASSED")
                else:
                    logger.error(f"✗ {test_name} FAILED")
            except Exception as e:
                logger.error(f"✗ {test_name} FAILED with exception: {e}")
        
        additional_success_rate = passed_additional / total_additional if total_additional > 0 else 1.0
        overall_success = additional_success_rate >= 0.8
        
        logger.info(f"Full test results: {passed_additional}/{total_additional} additional tests passed ({additional_success_rate:.1%})")
        
        return overall_success
    
    def cleanup_test_environment(self):
        """Cleanup test environment."""
        
        if self.temp_dir and Path(self.temp_dir).exists():
            try:
                shutil.rmtree(self.temp_dir)
                logger.info(f"Cleaned up test directory: {self.temp_dir}")
            except Exception as e:
                logger.warning(f"Failed to cleanup test directory: {e}")
    
    def generate_test_report(self) -> str:
        """Generate comprehensive test report."""
        
        report = f"""
# Version 5 BETA 1 Integration Test Report

## Test Summary
- **Version**: {self.version}
- **Test Date**: {time.strftime('%Y-%m-%d %H:%M:%S')}
- **Total Tests**: {len(self.test_results)}
- **Failed Tests**: {len(self.failed_tests)}
- **Success Rate**: {(len(self.test_results) - len(self.failed_tests)) / len(self.test_results) * 100:.1f}%

## Test Results

"""
        
        for test_name, result in self.test_results.items():
            status = "✓ PASSED" if result['success'] else "✗ FAILED"
            report += f"### {test_name.replace('_', ' ').title()}\n"
            report += f"**Status**: {status}\n\n"
            
            if 'error' in result:
                report += f"**Error**: {result['error']}\n\n"
            else:
                # Add relevant details
                for key, value in result.items():
                    if key != 'success' and not key.startswith('_'):
                        report += f"- **{key.replace('_', ' ').title()}**: {value}\n"
                report += "\n"
        
        if self.failed_tests:
            report += "## Failed Tests\n\n"
            for test in self.failed_tests:
                report += f"- {test.replace('_', ' ').title()}\n"
            report += "\n"
        
        report += "## Recommendations\n\n"
        if not self.failed_tests:
            report += "All tests passed successfully. The system is ready for production use.\n"
        else:
            report += "Some tests failed. Please review the failed tests and fix any issues before deployment.\n"
        
        return report

def main():
    """Main entry point for integration testing."""
    
    import argparse
    
    parser = argparse.ArgumentParser(description='Version 5 BETA 1 Integration Tester')
    parser.add_argument('--quick-test', action='store_true', help='Run quick test suite')
    parser.add_argument('--full-test', action='store_true', help='Run full test suite')
    parser.add_argument('--component-test', type=str, help='Test specific component')
    parser.add_argument('--performance-test', action='store_true', help='Run performance tests only')
    parser.add_argument('--report', type=str, help='Save test report to file')
    
    args = parser.parse_args()
    
    tester = V5IntegrationTester()
    
    try:
        success = False
        
        if args.quick_test:
            success = tester.run_quick_test()
        elif args.full_test:
            success = tester.run_full_test()
        elif args.component_test:
            # Component-specific testing
            if args.component_test == 'core':
                success = tester.test_core_components()
            elif args.component_test == 'hitl':
                success = tester.test_hitl_system()
            elif args.component_test == 'visualization':
                success = tester.test_visualization_system()
            elif args.component_test == 'robustness':
                success = tester.test_robustness_framework()
            else:
                logger.error(f"Unknown component: {args.component_test}")
                return 1
        elif args.performance_test:
            success = tester.test_performance()
        else:
            # Default to quick test
            success = tester.run_quick_test()
        
        # Generate report
        report = tester.generate_test_report()
        
        if args.report:
            with open(args.report, 'w') as f:
                f.write(report)
            logger.info(f"Test report saved to: {args.report}")
        else:
            print(report)
        
        # Return appropriate exit code
        return 0 if success else 1
        
    except Exception as e:
        logger.error(f"Testing failed with exception: {e}")
        traceback.print_exc()
        return 1
    
    finally:
        tester.cleanup_test_environment()

if __name__ == "__main__":
    sys.exit(main())

