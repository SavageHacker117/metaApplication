"""
Robustness Testing and Error Handling Framework for Version 5 BETA 1

This module provides comprehensive testing and error handling capabilities
to ensure the RL training system can gracefully handle various failure modes
and recover from errors without losing training progress.

Key features:
- Comprehensive error scenario testing
- Graceful recovery mechanisms
- CUDA OOM handling
- Asset and renderer failure recovery
- Network and I/O error handling
- Memory leak detection and prevention
- Automatic system health monitoring
- Detailed error reporting and logging
"""

import os
import sys
import time
import psutil
import logging
import traceback
import threading
import subprocess
from typing import Dict, List, Any, Optional, Callable, Tuple
from dataclasses import dataclass, field
from collections import defaultdict, deque
from pathlib import Path
from enum import Enum
import json
import pickle
import signal
from contextlib import contextmanager
import gc
import torch
import numpy as np

logger = logging.getLogger(__name__)

class ErrorType(Enum):
    """Types of errors that can occur in the system."""
    CUDA_OOM = "cuda_oom"
    RENDERER_FAILURE = "renderer_failure"
    ASSET_LOADING_FAILURE = "asset_loading_failure"
    NETWORK_ERROR = "network_error"
    IO_ERROR = "io_error"
    MEMORY_LEAK = "memory_leak"
    TRAINING_DIVERGENCE = "training_divergence"
    HITL_TIMEOUT = "hitl_timeout"
    VISUALIZATION_ERROR = "visualization_error"
    CURRICULUM_ERROR = "curriculum_error"
    REPLAY_BUFFER_ERROR = "replay_buffer_error"

class RecoveryStrategy(Enum):
    """Recovery strategies for different error types."""
    RESTART_COMPONENT = "restart_component"
    REDUCE_BATCH_SIZE = "reduce_batch_size"
    CLEAR_CACHE = "clear_cache"
    FALLBACK_MODE = "fallback_mode"
    SKIP_EPISODE = "skip_episode"
    EMERGENCY_SAVE = "emergency_save"
    GRACEFUL_SHUTDOWN = "graceful_shutdown"

@dataclass
class ErrorScenario:
    """Definition of an error scenario for testing."""
    name: str
    error_type: ErrorType
    description: str
    trigger_condition: Callable[[], bool]
    recovery_strategy: RecoveryStrategy
    test_function: Optional[Callable] = None
    expected_behavior: str = ""
    severity: str = "medium"  # low, medium, high, critical

@dataclass
class ErrorEvent:
    """Record of an error event."""
    timestamp: float
    error_type: ErrorType
    error_message: str
    stack_trace: str
    recovery_strategy: RecoveryStrategy
    recovery_success: bool
    recovery_time: float
    context: Dict[str, Any]
    episode: int = 0

@dataclass
class RobustnessConfig:
    """Configuration for robustness testing."""
    
    # Testing settings
    enable_stress_testing: bool = True
    enable_fault_injection: bool = True
    test_frequency: int = 100  # Test every N episodes
    
    # Memory monitoring
    memory_threshold_mb: int = 8000  # Alert threshold
    memory_critical_mb: int = 12000  # Critical threshold
    memory_check_interval: float = 30.0  # seconds
    
    # CUDA settings
    cuda_memory_threshold: float = 0.9  # 90% of GPU memory
    cuda_oom_recovery_attempts: int = 3
    
    # Recovery settings
    max_recovery_attempts: int = 5
    recovery_timeout: float = 60.0  # seconds
    emergency_save_interval: int = 50  # episodes
    
    # Health monitoring
    health_check_interval: float = 60.0  # seconds
    performance_degradation_threshold: float = 0.5
    
    # Logging settings
    detailed_error_logging: bool = True
    error_report_path: str = "error_reports_v5"
    max_error_history: int = 1000

class RobustnessTestingFramework:
    """
    Comprehensive robustness testing and error handling framework.
    
    Provides systematic testing of error scenarios, graceful recovery
    mechanisms, and continuous system health monitoring.
    """
    
    def __init__(self, config: Optional[RobustnessConfig] = None):
        self.config = config or RobustnessConfig()
        
        # Error tracking
        self.error_history: deque = deque(maxlen=self.config.max_error_history)
        self.error_statistics: Dict[ErrorType, Dict[str, int]] = defaultdict(lambda: defaultdict(int))
        self.recovery_statistics: Dict[RecoveryStrategy, Dict[str, int]] = defaultdict(lambda: defaultdict(int))
        
        # System monitoring
        self.system_health: Dict[str, Any] = {}
        self.performance_baseline: Dict[str, float] = {}
        self.health_alerts: List[Dict[str, Any]] = []
        
        # Testing components
        self.error_scenarios: List[ErrorScenario] = []
        self.active_tests: Dict[str, bool] = {}
        self.test_results: Dict[str, Dict[str, Any]] = {}
        
        # Recovery mechanisms
        self.recovery_handlers: Dict[ErrorType, Callable] = {}
        self.emergency_save_data: Dict[str, Any] = {}
        
        # Monitoring threads
        self.monitoring_threads: List[threading.Thread] = []
        self.shutdown_event = threading.Event()
        
        # Setup
        self._setup_error_scenarios()
        self._setup_recovery_handlers()
        self._setup_monitoring()
        
        # Create error report directory
        Path(self.config.error_report_path).mkdir(parents=True, exist_ok=True)
        
        logger.info("Robustness Testing Framework V5 initialized")
    
    def _setup_error_scenarios(self):
        """Setup predefined error scenarios for testing."""
        
        # CUDA OOM scenario
        self.error_scenarios.append(ErrorScenario(
            name="cuda_oom_test",
            error_type=ErrorType.CUDA_OOM,
            description="Test CUDA out-of-memory handling",
            trigger_condition=lambda: torch.cuda.is_available() and self._should_test_cuda_oom(),
            recovery_strategy=RecoveryStrategy.REDUCE_BATCH_SIZE,
            test_function=self._test_cuda_oom,
            expected_behavior="Reduce batch size and continue training",
            severity="high"
        ))
        
        # Renderer failure scenario
        self.error_scenarios.append(ErrorScenario(
            name="renderer_failure_test",
            error_type=ErrorType.RENDERER_FAILURE,
            description="Test renderer failure and fallback",
            trigger_condition=lambda: self._should_test_renderer_failure(),
            recovery_strategy=RecoveryStrategy.FALLBACK_MODE,
            test_function=self._test_renderer_failure,
            expected_behavior="Switch to fallback renderer",
            severity="medium"
        ))
        
        # Asset loading failure scenario
        self.error_scenarios.append(ErrorScenario(
            name="asset_loading_failure_test",
            error_type=ErrorType.ASSET_LOADING_FAILURE,
            description="Test asset loading failure handling",
            trigger_condition=lambda: self._should_test_asset_loading(),
            recovery_strategy=RecoveryStrategy.FALLBACK_MODE,
            test_function=self._test_asset_loading_failure,
            expected_behavior="Use default assets and continue",
            severity="low"
        ))
        
        # Memory leak scenario
        self.error_scenarios.append(ErrorScenario(
            name="memory_leak_test",
            error_type=ErrorType.MEMORY_LEAK,
            description="Test memory leak detection and cleanup",
            trigger_condition=lambda: self._should_test_memory_leak(),
            recovery_strategy=RecoveryStrategy.CLEAR_CACHE,
            test_function=self._test_memory_leak,
            expected_behavior="Clear caches and garbage collect",
            severity="high"
        ))
        
        # Training divergence scenario
        self.error_scenarios.append(ErrorScenario(
            name="training_divergence_test",
            error_type=ErrorType.TRAINING_DIVERGENCE,
            description="Test training divergence detection",
            trigger_condition=lambda: self._should_test_training_divergence(),
            recovery_strategy=RecoveryStrategy.EMERGENCY_SAVE,
            test_function=self._test_training_divergence,
            expected_behavior="Save state and adjust learning parameters",
            severity="critical"
        ))
        
        logger.info(f"Setup {len(self.error_scenarios)} error scenarios")
    
    def _setup_recovery_handlers(self):
        """Setup recovery handlers for different error types."""
        
        self.recovery_handlers = {
            ErrorType.CUDA_OOM: self._handle_cuda_oom,
            ErrorType.RENDERER_FAILURE: self._handle_renderer_failure,
            ErrorType.ASSET_LOADING_FAILURE: self._handle_asset_loading_failure,
            ErrorType.NETWORK_ERROR: self._handle_network_error,
            ErrorType.IO_ERROR: self._handle_io_error,
            ErrorType.MEMORY_LEAK: self._handle_memory_leak,
            ErrorType.TRAINING_DIVERGENCE: self._handle_training_divergence,
            ErrorType.HITL_TIMEOUT: self._handle_hitl_timeout,
            ErrorType.VISUALIZATION_ERROR: self._handle_visualization_error,
            ErrorType.CURRICULUM_ERROR: self._handle_curriculum_error,
            ErrorType.REPLAY_BUFFER_ERROR: self._handle_replay_buffer_error
        }
        
        logger.info(f"Setup {len(self.recovery_handlers)} recovery handlers")
    
    def _setup_monitoring(self):
        """Setup system health monitoring."""
        
        # Memory monitoring thread
        memory_monitor = threading.Thread(target=self._memory_monitor, daemon=True)
        memory_monitor.start()
        self.monitoring_threads.append(memory_monitor)
        
        # Health check thread
        health_monitor = threading.Thread(target=self._health_monitor, daemon=True)
        health_monitor.start()
        self.monitoring_threads.append(health_monitor)
        
        # Performance monitor
        performance_monitor = threading.Thread(target=self._performance_monitor, daemon=True)
        performance_monitor.start()
        self.monitoring_threads.append(performance_monitor)
        
        logger.info("System monitoring started")
    
    def run_robustness_tests(self, episode: int, context: Dict[str, Any]) -> Dict[str, Any]:
        """
        Run robustness tests for the current episode.
        
        Args:
            episode: Current episode number
            context: Current training context
            
        Returns:
            Dictionary with test results
        """
        
        if not self.config.enable_stress_testing:
            return {}
        
        if episode % self.config.test_frequency != 0:
            return {}
        
        test_results = {}
        
        for scenario in self.error_scenarios:
            try:
                # Check if scenario should be triggered
                if scenario.trigger_condition():
                    logger.info(f"Running robustness test: {scenario.name}")
                    
                    # Run the test
                    result = self._run_error_scenario(scenario, episode, context)
                    test_results[scenario.name] = result
                    
                    # Store test result
                    self.test_results[scenario.name] = result
                    
            except Exception as e:
                logger.error(f"Error running test {scenario.name}: {e}")
                test_results[scenario.name] = {
                    'success': False,
                    'error': str(e),
                    'timestamp': time.time()
                }
        
        return test_results
    
    def _run_error_scenario(self, scenario: ErrorScenario, episode: int, context: Dict[str, Any]) -> Dict[str, Any]:
        """Run a specific error scenario test."""
        
        start_time = time.time()
        
        try:
            # Execute test function if available
            if scenario.test_function:
                test_success = scenario.test_function(context)
            else:
                test_success = True
            
            # Simulate error if fault injection is enabled
            if self.config.enable_fault_injection:
                self._inject_fault(scenario.error_type, context)
            
            end_time = time.time()
            
            return {
                'success': test_success,
                'execution_time': end_time - start_time,
                'scenario': scenario.name,
                'error_type': scenario.error_type.value,
                'recovery_strategy': scenario.recovery_strategy.value,
                'episode': episode,
                'timestamp': start_time
            }
            
        except Exception as e:
            return {
                'success': False,
                'error': str(e),
                'execution_time': time.time() - start_time,
                'scenario': scenario.name,
                'episode': episode,
                'timestamp': start_time
            }
    
    def handle_error(self, error_type: ErrorType, error_message: str, context: Dict[str, Any]) -> bool:
        """
        Handle an error using the appropriate recovery strategy.
        
        Args:
            error_type: Type of error that occurred
            error_message: Error message
            context: Current context information
            
        Returns:
            True if recovery was successful, False otherwise
        """
        
        start_time = time.time()
        
        # Create error event
        error_event = ErrorEvent(
            timestamp=start_time,
            error_type=error_type,
            error_message=error_message,
            stack_trace=traceback.format_exc(),
            recovery_strategy=RecoveryStrategy.RESTART_COMPONENT,  # Default
            recovery_success=False,
            recovery_time=0.0,
            context=context.copy(),
            episode=context.get('episode', 0)
        )
        
        try:
            # Get recovery handler
            recovery_handler = self.recovery_handlers.get(error_type)
            
            if recovery_handler:
                logger.info(f"Attempting recovery for {error_type.value}: {error_message}")
                
                # Attempt recovery
                recovery_success = recovery_handler(error_message, context)
                
                # Update error event
                error_event.recovery_success = recovery_success
                error_event.recovery_time = time.time() - start_time
                
                # Update statistics
                self.error_statistics[error_type]['total'] += 1
                if recovery_success:
                    self.error_statistics[error_type]['recovered'] += 1
                else:
                    self.error_statistics[error_type]['failed'] += 1
                
                # Log error event
                self.error_history.append(error_event)
                
                # Generate error report if detailed logging is enabled
                if self.config.detailed_error_logging:
                    self._generate_error_report(error_event)
                
                return recovery_success
            
            else:
                logger.error(f"No recovery handler for error type: {error_type.value}")
                error_event.recovery_success = False
                self.error_history.append(error_event)
                return False
                
        except Exception as recovery_error:
            logger.error(f"Recovery attempt failed: {recovery_error}")
            error_event.recovery_success = False
            error_event.error_message += f" | Recovery error: {str(recovery_error)}"
            self.error_history.append(error_event)
            return False
    
    # Error scenario test functions
    def _should_test_cuda_oom(self) -> bool:
        """Check if CUDA OOM test should be triggered."""
        if not torch.cuda.is_available():
            return False
        
        # Check GPU memory usage
        gpu_memory_used = torch.cuda.memory_allocated() / torch.cuda.max_memory_allocated()
        return gpu_memory_used > self.config.cuda_memory_threshold
    
    def _test_cuda_oom(self, context: Dict[str, Any]) -> bool:
        """Test CUDA out-of-memory handling."""
        try:
            # Simulate CUDA OOM by allocating large tensor
            if torch.cuda.is_available():
                # Get available memory
                available_memory = torch.cuda.get_device_properties(0).total_memory
                
                # Try to allocate more memory than available
                large_tensor = torch.randn(int(available_memory // 4), device='cuda')
                del large_tensor
                torch.cuda.empty_cache()
            
            return True
            
        except RuntimeError as e:
            if "out of memory" in str(e).lower():
                # This is expected - test the recovery
                return self.handle_error(ErrorType.CUDA_OOM, str(e), context)
            else:
                raise e
    
    def _should_test_renderer_failure(self) -> bool:
        """Check if renderer failure test should be triggered."""
        return True  # Can always test renderer failure
    
    def _test_renderer_failure(self, context: Dict[str, Any]) -> bool:
        """Test renderer failure handling."""
        try:
            # Simulate renderer failure
            raise RuntimeError("Simulated renderer failure")
        except RuntimeError as e:
            return self.handle_error(ErrorType.RENDERER_FAILURE, str(e), context)
    
    def _should_test_asset_loading(self) -> bool:
        """Check if asset loading test should be triggered."""
        return True
    
    def _test_asset_loading_failure(self, context: Dict[str, Any]) -> bool:
        """Test asset loading failure handling."""
        try:
            # Simulate asset loading failure
            raise FileNotFoundError("Simulated asset loading failure")
        except FileNotFoundError as e:
            return self.handle_error(ErrorType.ASSET_LOADING_FAILURE, str(e), context)
    
    def _should_test_memory_leak(self) -> bool:
        """Check if memory leak test should be triggered."""
        current_memory = psutil.Process().memory_info().rss / 1024 / 1024  # MB
        return current_memory > self.config.memory_threshold_mb
    
    def _test_memory_leak(self, context: Dict[str, Any]) -> bool:
        """Test memory leak detection and cleanup."""
        try:
            # Simulate memory leak detection
            current_memory = psutil.Process().memory_info().rss / 1024 / 1024
            
            if current_memory > self.config.memory_critical_mb:
                raise MemoryError(f"Memory usage critical: {current_memory:.1f} MB")
            
            return True
            
        except MemoryError as e:
            return self.handle_error(ErrorType.MEMORY_LEAK, str(e), context)
    
    def _should_test_training_divergence(self) -> bool:
        """Check if training divergence test should be triggered."""
        return True
    
    def _test_training_divergence(self, context: Dict[str, Any]) -> bool:
        """Test training divergence detection."""
        try:
            # Check for training divergence indicators
            recent_rewards = context.get('recent_rewards', [])
            
            if len(recent_rewards) > 10:
                # Check for NaN or infinite values
                if any(np.isnan(r) or np.isinf(r) for r in recent_rewards):
                    raise ValueError("Training divergence detected: NaN or infinite rewards")
                
                # Check for extreme values
                if any(abs(r) > 1000 for r in recent_rewards):
                    raise ValueError("Training divergence detected: extreme reward values")
            
            return True
            
        except ValueError as e:
            return self.handle_error(ErrorType.TRAINING_DIVERGENCE, str(e), context)
    
    def _inject_fault(self, error_type: ErrorType, context: Dict[str, Any]):
        """Inject a fault for testing purposes."""
        
        if not self.config.enable_fault_injection:
            return
        
        # Randomly inject faults with low probability
        if np.random.random() > 0.95:  # 5% chance
            if error_type == ErrorType.CUDA_OOM:
                if torch.cuda.is_available():
                    # Force CUDA OOM
                    try:
                        huge_tensor = torch.randn(10000, 10000, device='cuda')
                    except RuntimeError:
                        pass  # Expected
            
            elif error_type == ErrorType.IO_ERROR:
                # Simulate I/O error
                raise IOError("Injected I/O error for testing")
            
            elif error_type == ErrorType.NETWORK_ERROR:
                # Simulate network error
                raise ConnectionError("Injected network error for testing")
    
    # Recovery handlers
    def _handle_cuda_oom(self, error_message: str, context: Dict[str, Any]) -> bool:
        """Handle CUDA out-of-memory errors."""
        
        logger.info("Handling CUDA OOM error")
        
        try:
            # Clear CUDA cache
            if torch.cuda.is_available():
                torch.cuda.empty_cache()
            
            # Reduce batch size if possible
            current_batch_size = context.get('batch_size', 32)
            new_batch_size = max(1, current_batch_size // 2)
            
            context['batch_size'] = new_batch_size
            context['cuda_oom_recovery'] = True
            
            logger.info(f"Reduced batch size from {current_batch_size} to {new_batch_size}")
            
            # Force garbage collection
            gc.collect()
            
            return True
            
        except Exception as e:
            logger.error(f"CUDA OOM recovery failed: {e}")
            return False
    
    def _handle_renderer_failure(self, error_message: str, context: Dict[str, Any]) -> bool:
        """Handle renderer failures."""
        
        logger.info("Handling renderer failure")
        
        try:
            # Switch to fallback renderer
            context['use_fallback_renderer'] = True
            context['renderer_failure_recovery'] = True
            
            # Disable advanced rendering features
            context['disable_advanced_rendering'] = True
            
            logger.info("Switched to fallback renderer")
            
            return True
            
        except Exception as e:
            logger.error(f"Renderer failure recovery failed: {e}")
            return False
    
    def _handle_asset_loading_failure(self, error_message: str, context: Dict[str, Any]) -> bool:
        """Handle asset loading failures."""
        
        logger.info("Handling asset loading failure")
        
        try:
            # Use default assets
            context['use_default_assets'] = True
            context['asset_loading_failure_recovery'] = True
            
            # Disable NeRF assets temporarily
            context['disable_nerf_assets'] = True
            
            logger.info("Switched to default assets")
            
            return True
            
        except Exception as e:
            logger.error(f"Asset loading failure recovery failed: {e}")
            return False
    
    def _handle_network_error(self, error_message: str, context: Dict[str, Any]) -> bool:
        """Handle network errors."""
        
        logger.info("Handling network error")
        
        try:
            # Disable network-dependent features
            context['disable_wandb'] = True
            context['disable_remote_logging'] = True
            context['network_error_recovery'] = True
            
            logger.info("Disabled network-dependent features")
            
            return True
            
        except Exception as e:
            logger.error(f"Network error recovery failed: {e}")
            return False
    
    def _handle_io_error(self, error_message: str, context: Dict[str, Any]) -> bool:
        """Handle I/O errors."""
        
        logger.info("Handling I/O error")
        
        try:
            # Switch to alternative storage location
            context['use_backup_storage'] = True
            context['io_error_recovery'] = True
            
            # Reduce I/O frequency
            context['reduce_io_frequency'] = True
            
            logger.info("Switched to backup storage and reduced I/O frequency")
            
            return True
            
        except Exception as e:
            logger.error(f"I/O error recovery failed: {e}")
            return False
    
    def _handle_memory_leak(self, error_message: str, context: Dict[str, Any]) -> bool:
        """Handle memory leaks."""
        
        logger.info("Handling memory leak")
        
        try:
            # Force garbage collection
            gc.collect()
            
            # Clear caches
            if hasattr(context, 'clear_caches'):
                context['clear_caches']()
            
            # Clear CUDA cache if available
            if torch.cuda.is_available():
                torch.cuda.empty_cache()
            
            # Reduce memory usage
            context['reduce_memory_usage'] = True
            context['memory_leak_recovery'] = True
            
            logger.info("Cleared caches and reduced memory usage")
            
            return True
            
        except Exception as e:
            logger.error(f"Memory leak recovery failed: {e}")
            return False
    
    def _handle_training_divergence(self, error_message: str, context: Dict[str, Any]) -> bool:
        """Handle training divergence."""
        
        logger.info("Handling training divergence")
        
        try:
            # Emergency save
            self._emergency_save(context)
            
            # Reset learning rate
            context['reset_learning_rate'] = True
            context['training_divergence_recovery'] = True
            
            # Reduce learning rate
            current_lr = context.get('learning_rate', 0.001)
            new_lr = current_lr * 0.1
            context['learning_rate'] = new_lr
            
            logger.info(f"Emergency save completed, reduced learning rate to {new_lr}")
            
            return True
            
        except Exception as e:
            logger.error(f"Training divergence recovery failed: {e}")
            return False
    
    def _handle_hitl_timeout(self, error_message: str, context: Dict[str, Any]) -> bool:
        """Handle HITL timeout errors."""
        
        logger.info("Handling HITL timeout")
        
        try:
            # Skip HITL feedback for this episode
            context['skip_hitl_feedback'] = True
            context['hitl_timeout_recovery'] = True
            
            logger.info("Skipped HITL feedback due to timeout")
            
            return True
            
        except Exception as e:
            logger.error(f"HITL timeout recovery failed: {e}")
            return False
    
    def _handle_visualization_error(self, error_message: str, context: Dict[str, Any]) -> bool:
        """Handle visualization errors."""
        
        logger.info("Handling visualization error")
        
        try:
            # Disable visualization temporarily
            context['disable_visualization'] = True
            context['visualization_error_recovery'] = True
            
            logger.info("Disabled visualization due to error")
            
            return True
            
        except Exception as e:
            logger.error(f"Visualization error recovery failed: {e}")
            return False
    
    def _handle_curriculum_error(self, error_message: str, context: Dict[str, Any]) -> bool:
        """Handle curriculum learning errors."""
        
        logger.info("Handling curriculum error")
        
        try:
            # Reset curriculum to safe state
            context['reset_curriculum'] = True
            context['curriculum_error_recovery'] = True
            
            logger.info("Reset curriculum to safe state")
            
            return True
            
        except Exception as e:
            logger.error(f"Curriculum error recovery failed: {e}")
            return False
    
    def _handle_replay_buffer_error(self, error_message: str, context: Dict[str, Any]) -> bool:
        """Handle replay buffer errors."""
        
        logger.info("Handling replay buffer error")
        
        try:
            # Clear replay buffer
            context['clear_replay_buffer'] = True
            context['replay_buffer_error_recovery'] = True
            
            logger.info("Cleared replay buffer due to error")
            
            return True
            
        except Exception as e:
            logger.error(f"Replay buffer error recovery failed: {e}")
            return False
    
    def _emergency_save(self, context: Dict[str, Any]):
        """Perform emergency save of training state."""
        
        try:
            timestamp = int(time.time())
            save_path = Path(self.config.error_report_path) / f"emergency_save_{timestamp}.pkl"
            
            # Collect important state
            emergency_data = {
                'timestamp': timestamp,
                'episode': context.get('episode', 0),
                'context': context.copy(),
                'error_history': list(self.error_history)[-10:],  # Last 10 errors
                'system_health': self.system_health.copy()
            }
            
            # Save to file
            with open(save_path, 'wb') as f:
                pickle.dump(emergency_data, f)
            
            logger.info(f"Emergency save completed: {save_path}")
            
        except Exception as e:
            logger.error(f"Emergency save failed: {e}")
    
    # Monitoring functions
    def _memory_monitor(self):
        """Monitor system memory usage."""
        
        while not self.shutdown_event.is_set():
            try:
                # Get memory info
                process = psutil.Process()
                memory_info = process.memory_info()
                memory_mb = memory_info.rss / 1024 / 1024
                
                # Update system health
                self.system_health['memory_usage_mb'] = memory_mb
                self.system_health['memory_percent'] = process.memory_percent()
                
                # Check thresholds
                if memory_mb > self.config.memory_critical_mb:
                    alert = {
                        'type': 'critical_memory',
                        'message': f'Critical memory usage: {memory_mb:.1f} MB',
                        'timestamp': time.time(),
                        'severity': 'critical'
                    }
                    self.health_alerts.append(alert)
                    logger.critical(alert['message'])
                
                elif memory_mb > self.config.memory_threshold_mb:
                    alert = {
                        'type': 'high_memory',
                        'message': f'High memory usage: {memory_mb:.1f} MB',
                        'timestamp': time.time(),
                        'severity': 'warning'
                    }
                    self.health_alerts.append(alert)
                    logger.warning(alert['message'])
                
                # CUDA memory if available
                if torch.cuda.is_available():
                    cuda_allocated = torch.cuda.memory_allocated() / 1024 / 1024
                    cuda_cached = torch.cuda.memory_reserved() / 1024 / 1024
                    
                    self.system_health['cuda_memory_allocated_mb'] = cuda_allocated
                    self.system_health['cuda_memory_cached_mb'] = cuda_cached
                
                time.sleep(self.config.memory_check_interval)
                
            except Exception as e:
                logger.error(f"Memory monitoring error: {e}")
                time.sleep(10)
    
    def _health_monitor(self):
        """Monitor overall system health."""
        
        while not self.shutdown_event.is_set():
            try:
                # CPU usage
                cpu_percent = psutil.cpu_percent(interval=1)
                self.system_health['cpu_percent'] = cpu_percent
                
                # Disk usage
                disk_usage = psutil.disk_usage('/')
                self.system_health['disk_usage_percent'] = (disk_usage.used / disk_usage.total) * 100
                
                # GPU temperature if available
                try:
                    if torch.cuda.is_available():
                        gpu_temp = torch.cuda.temperature()
                        self.system_health['gpu_temperature'] = gpu_temp
                except:
                    pass  # GPU temperature not available
                
                # Check for system issues
                if cpu_percent > 95:
                    alert = {
                        'type': 'high_cpu',
                        'message': f'High CPU usage: {cpu_percent:.1f}%',
                        'timestamp': time.time(),
                        'severity': 'warning'
                    }
                    self.health_alerts.append(alert)
                
                time.sleep(self.config.health_check_interval)
                
            except Exception as e:
                logger.error(f"Health monitoring error: {e}")
                time.sleep(30)
    
    def _performance_monitor(self):
        """Monitor training performance."""
        
        while not self.shutdown_event.is_set():
            try:
                # This would integrate with the training system
                # to monitor performance metrics
                
                # Placeholder for performance monitoring
                time.sleep(60)
                
            except Exception as e:
                logger.error(f"Performance monitoring error: {e}")
                time.sleep(30)
    
    def _generate_error_report(self, error_event: ErrorEvent):
        """Generate detailed error report."""
        
        try:
            timestamp = int(error_event.timestamp)
            report_path = Path(self.config.error_report_path) / f"error_report_{timestamp}.json"
            
            report_data = {
                'error_event': {
                    'timestamp': error_event.timestamp,
                    'error_type': error_event.error_type.value,
                    'error_message': error_event.error_message,
                    'stack_trace': error_event.stack_trace,
                    'recovery_strategy': error_event.recovery_strategy.value,
                    'recovery_success': error_event.recovery_success,
                    'recovery_time': error_event.recovery_time,
                    'episode': error_event.episode
                },
                'context': error_event.context,
                'system_health': self.system_health.copy(),
                'error_statistics': {
                    error_type.value: dict(stats) 
                    for error_type, stats in self.error_statistics.items()
                }
            }
            
            with open(report_path, 'w') as f:
                json.dump(report_data, f, indent=2, default=str)
            
            logger.info(f"Error report generated: {report_path}")
            
        except Exception as e:
            logger.error(f"Failed to generate error report: {e}")
    
    def get_robustness_statistics(self) -> Dict[str, Any]:
        """Get comprehensive robustness statistics."""
        
        stats = {
            'total_errors': len(self.error_history),
            'error_types': {
                error_type.value: dict(stats)
                for error_type, stats in self.error_statistics.items()
            },
            'recovery_success_rate': self._calculate_recovery_success_rate(),
            'system_health': self.system_health.copy(),
            'recent_alerts': self.health_alerts[-10:],
            'test_results': self.test_results.copy(),
            'active_monitoring': len(self.monitoring_threads)
        }
        
        return stats
    
    def _calculate_recovery_success_rate(self) -> float:
        """Calculate overall recovery success rate."""
        
        total_errors = sum(
            stats['total'] for stats in self.error_statistics.values()
        )
        
        if total_errors == 0:
            return 1.0
        
        total_recovered = sum(
            stats['recovered'] for stats in self.error_statistics.values()
        )
        
        return total_recovered / total_errors
    
    @contextmanager
    def error_handling_context(self, context: Dict[str, Any]):
        """Context manager for automatic error handling."""
        
        try:
            yield
        except Exception as e:
            # Determine error type based on exception
            error_type = self._classify_error(e)
            
            # Handle the error
            recovery_success = self.handle_error(error_type, str(e), context)
            
            if not recovery_success:
                # If recovery failed, re-raise the exception
                raise e
    
    def _classify_error(self, exception: Exception) -> ErrorType:
        """Classify an exception into an error type."""
        
        error_message = str(exception).lower()
        
        if "out of memory" in error_message or "cuda" in error_message:
            return ErrorType.CUDA_OOM
        elif "render" in error_message:
            return ErrorType.RENDERER_FAILURE
        elif "file not found" in error_message or "asset" in error_message:
            return ErrorType.ASSET_LOADING_FAILURE
        elif "network" in error_message or "connection" in error_message:
            return ErrorType.NETWORK_ERROR
        elif "io" in error_message or "disk" in error_message:
            return ErrorType.IO_ERROR
        elif "memory" in error_message:
            return ErrorType.MEMORY_LEAK
        elif "nan" in error_message or "inf" in error_message:
            return ErrorType.TRAINING_DIVERGENCE
        elif "timeout" in error_message:
            return ErrorType.HITL_TIMEOUT
        elif "visualization" in error_message or "plot" in error_message:
            return ErrorType.VISUALIZATION_ERROR
        elif "curriculum" in error_message:
            return ErrorType.CURRICULUM_ERROR
        elif "replay" in error_message or "buffer" in error_message:
            return ErrorType.REPLAY_BUFFER_ERROR
        else:
            return ErrorType.IO_ERROR  # Default fallback
    
    def cleanup(self):
        """Cleanup robustness testing resources."""
        
        # Signal shutdown
        self.shutdown_event.set()
        
        # Wait for monitoring threads to finish
        for thread in self.monitoring_threads:
            thread.join(timeout=5)
        
        # Generate final report
        final_stats = self.get_robustness_statistics()
        
        try:
            final_report_path = Path(self.config.error_report_path) / "final_robustness_report.json"
            with open(final_report_path, 'w') as f:
                json.dump(final_stats, f, indent=2, default=str)
            
            logger.info(f"Final robustness report saved: {final_report_path}")
        except Exception as e:
            logger.error(f"Failed to save final report: {e}")
        
        logger.info("Robustness Testing Framework cleanup completed")

# Example usage
if __name__ == "__main__":
    config = RobustnessConfig(
        enable_stress_testing=True,
        enable_fault_injection=False,  # Disable for production
        test_frequency=50
    )
    
    robustness_framework = RobustnessTestingFramework(config)
    
    # Simulate training episodes with error handling
    for episode in range(200):
        context = {
            'episode': episode,
            'batch_size': 32,
            'learning_rate': 0.001,
            'recent_rewards': [np.random.normal(10, 2) for _ in range(20)]
        }
        
        # Run robustness tests
        test_results = robustness_framework.run_robustness_tests(episode, context)
        
        if test_results:
            print(f"Episode {episode}: Ran {len(test_results)} robustness tests")
        
        # Simulate some errors occasionally
        if episode % 30 == 0:
            try:
                with robustness_framework.error_handling_context(context):
                    if np.random.random() < 0.3:  # 30% chance of error
                        raise RuntimeError("Simulated training error")
            except Exception as e:
                print(f"Episode {episode}: Handled error - {e}")
        
        time.sleep(0.1)  # Simulate episode time
    
    # Get final statistics
    stats = robustness_framework.get_robustness_statistics()
    print(f"Final robustness statistics: {stats}")
    
    # Cleanup
    robustness_framework.cleanup()

